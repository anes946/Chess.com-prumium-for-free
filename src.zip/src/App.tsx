import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Chess, Square } from 'chess.js';
import {
  AIDifficulty,
  GameMode,
  GameReviewReport,
  GameSettings,
  MoveAnalysis,
  PieceColor,
  PlayerProfile,
  TimeControl,
} from './types/chess';
import { ChessBoard } from './components/ChessBoard';
import { ChessClock } from './components/ChessClock';
import { MoveHistory } from './components/MoveHistory';
import { EvalBar } from './components/EvalBar';
import { AnalysisPanel } from './components/AnalysisPanel';
import { NewGameModal, TIME_CONTROLS } from './components/NewGameModal';
import { PgnModal } from './components/PgnModal';
import { ProfileModal } from './components/ProfileModal';
import { SettingsModal } from './components/SettingsModal';
import { GameOverModal } from './components/GameOverModal';
import { evaluateBoard, getAIMove } from './utils/aiEngine';
import { reviewGame } from './utils/analysisEngine';
import { soundService } from './utils/sound';
import {
  Swords,
  Bot,
  RotateCcw,
  Flag,
  FileText,
  Sparkles,
  Settings,
  User,
  ArrowRight,
  Eye,
} from 'lucide-react';

const DEFAULT_PROFILE: PlayerProfile = {
  id: 'player_1',
  name: 'Grandmaster',
  avatar: '♟️',
  elo: 1200,
  highestElo: 1200,
  gamesPlayed: 0,
  wins: 0,
  losses: 0,
  draws: 0,
  history: [],
};

const DEFAULT_SETTINGS: GameSettings = {
  boardTheme: 'emerald',
  soundEnabled: true,
  soundVolume: 0.6,
  showLegalMoves: true,
  showEvaluationBar: true,
  autoFlipOnPvp: true,
  showCoordinates: true,
  themeMode: 'dark',
};

export default function App() {
  // Live game state (immutable source of truth for the game in progress)
  const [liveChess, setLiveChess] = useState<Chess>(() => new Chess());
  const [gameMode, setGameMode] = useState<GameMode>('ai');
  const [aiDifficulty, setAiDifficulty] = useState<AIDifficulty>('intermediate');
  const [userColor, setUserColor] = useState<PieceColor>('w');
  const [isFlipped, setIsFlipped] = useState(false);
  const [isAiThinking, setIsAiThinking] = useState(false);

  // Time controls & clocks
  const [timeControl, setTimeControl] = useState<TimeControl>(TIME_CONTROLS[4]); // 10 min
  const [whiteTime, setWhiteTime] = useState(600);
  const [blackTime, setBlackTime] = useState(600);
  const [isClockRunning, setIsClockRunning] = useState(false);

  // Move history
  const [moveHistory, setMoveHistory] = useState<
    Array<{
      san: string;
      from: string;
      to: string;
      color: PieceColor;
      fenAfter: string;
      analysis?: MoveAnalysis;
    }>
  >([]);

  // Navigation index: -1 at game start, 0..moveHistory.length-1
  const [viewMoveIndex, setViewMoveIndex] = useState<number>(-1);

  // Evaluation & analysis
  const [evalScore, setEvalScore] = useState<number>(0);
  const [reviewReport, setReviewReport] = useState<GameReviewReport | null>(null);
  const [isAnalyzingGame, setIsAnalyzingGame] = useState(false);
  const [activeTab, setActiveTab] = useState<'moves' | 'analysis'>('moves');

  // Modals
  const [isNewGameOpen, setIsNewGameOpen] = useState(false);
  const [isPgnOpen, setIsPgnOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [gameOverInfo, setGameOverInfo] = useState<{
    isOpen: boolean;
    result: 'white_won' | 'black_won' | 'draw';
    reason: string;
  }>({ isOpen: false, result: 'draw', reason: '' });

  // Persistent Profile & Settings
  const [profile, setProfile] = useState<PlayerProfile>(() => {
    try {
      const saved = localStorage.getItem('chess_profile_data');
      return saved ? JSON.parse(saved) : DEFAULT_PROFILE;
    } catch {
      return DEFAULT_PROFILE;
    }
  });

  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const saved = localStorage.getItem('chess_settings_data');
      return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Sync settings
  useEffect(() => {
    localStorage.setItem('chess_settings_data', JSON.stringify(settings));
    soundService.setEnabled(settings.soundEnabled);
    soundService.setVolume(settings.soundVolume);

    if (settings.themeMode === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  // Sync profile
  useEffect(() => {
    localStorage.setItem('chess_profile_data', JSON.stringify(profile));
  }, [profile]);

  // Determine whether the user is reviewing history or viewing live game
  const isViewingHistory = viewMoveIndex !== -1 && viewMoveIndex !== moveHistory.length - 1;

  // Compute the board to display:
  // If viewing history, construct a read-only board at that historical FEN
  // If at live position, use liveChess
  const displayChess = useMemo(() => {
    if (moveHistory.length === 0 || viewMoveIndex === moveHistory.length - 1) {
      return liveChess;
    }
    if (viewMoveIndex === -1) {
      return new Chess();
    }
    const targetMove = moveHistory[viewMoveIndex];
    if (targetMove) {
      try {
        return new Chess(targetMove.fenAfter);
      } catch {
        return liveChess;
      }
    }
    return liveChess;
  }, [liveChess, moveHistory, viewMoveIndex]);

  // Recalculate eval score whenever display position changes
  useEffect(() => {
    const score = evaluateBoard(displayChess) / 100;
    setEvalScore(score);
  }, [displayChess]);

  // Handle Game End & Elo updates
  const handleGameEnd = useCallback(
    (result: 'white_won' | 'black_won' | 'draw', reason: string) => {
      setIsClockRunning(false);

      let eloDelta = 0;
      let matchResult: 'win' | 'loss' | 'draw' = 'draw';

      if (gameMode === 'ai') {
        const userWon =
          (result === 'white_won' && userColor === 'w') ||
          (result === 'black_won' && userColor === 'b');
        const userLost =
          (result === 'black_won' && userColor === 'w') ||
          (result === 'white_won' && userColor === 'b');

        if (userWon) {
          matchResult = 'win';
          eloDelta = 15;
        } else if (userLost) {
          matchResult = 'loss';
          eloDelta = -12;
        } else {
          matchResult = 'draw';
          eloDelta = 2;
        }

        setProfile((prev) => {
          const newElo = Math.max(100, prev.elo + eloDelta);
          return {
            ...prev,
            elo: newElo,
            highestElo: Math.max(prev.highestElo, newElo),
            gamesPlayed: prev.gamesPlayed + 1,
            wins: prev.wins + (matchResult === 'win' ? 1 : 0),
            losses: prev.losses + (matchResult === 'loss' ? 1 : 0),
            draws: prev.draws + (matchResult === 'draw' ? 1 : 0),
            history: [
              {
                date: new Date().toLocaleDateString(),
                opponent: `AI ${aiDifficulty.toUpperCase()}`,
                result: matchResult,
                eloChange: eloDelta,
                pgn: liveChess.pgn(),
              },
              ...prev.history.slice(0, 24),
            ],
          };
        });
      }

      setGameOverInfo({ isOpen: true, result, reason });
    },
    [gameMode, userColor, aiDifficulty, liveChess]
  );

  // Handle player time out
  const handleTimeOut = useCallback(
    (timedOutColor: PieceColor) => {
      setIsClockRunning(false);
      soundService.playGameOver(timedOutColor !== userColor);
      const winner = timedOutColor === 'w' ? 'black_won' : 'white_won';
      handleGameEnd(winner, `${timedOutColor === 'w' ? 'White' : 'Black'} ran out of time!`);
    },
    [userColor, handleGameEnd]
  );

  // Chess clock countdown (runs strictly on liveChess)
  useEffect(() => {
    if (!isClockRunning || timeControl.initialMinutes === 0 || liveChess.isGameOver()) return;

    const interval = setInterval(() => {
      const turn = liveChess.turn();
      if (turn === 'w') {
        setWhiteTime((prev) => {
          if (prev <= 1) {
            handleTimeOut('w');
            return 0;
          }
          if (prev <= 10) soundService.playTick();
          return prev - 1;
        });
      } else {
        setBlackTime((prev) => {
          if (prev <= 1) {
            handleTimeOut('b');
            return 0;
          }
          if (prev <= 10) soundService.playTick();
          return prev - 1;
        });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isClockRunning, liveChess, timeControl, handleTimeOut]);

  // Check live game over status
  const verifyGameStatus = useCallback(
    (currentChess: Chess) => {
      if (currentChess.isCheckmate()) {
        const winner = currentChess.turn() === 'w' ? 'black_won' : 'white_won';
        soundService.playGameOver(
          (winner === 'white_won' && userColor === 'w') ||
          (winner === 'black_won' && userColor === 'b')
        );
        handleGameEnd(winner, 'Checkmate! King has no legal escape.');
      } else if (currentChess.isDraw()) {
        let reason = 'Draw';
        if (currentChess.isStalemate()) reason = 'Draw by Stalemate';
        else if (currentChess.isThreefoldRepetition()) reason = 'Draw by Threefold Repetition';
        else if (currentChess.isInsufficientMaterial()) reason = 'Draw by Insufficient Material';
        soundService.playGameOver(false);
        handleGameEnd('draw', reason);
      }
    },
    [userColor, handleGameEnd]
  );

  // Execute a move on the live board
  const executeMove = useCallback(
    (from: Square, to: Square, promotion?: string): boolean => {
      try {
        // If user was viewing history, return to live position first
        const nextChess = new Chess(liveChess.fen());
        const isCapture = nextChess.get(to) !== null || (nextChess.get(from)?.type === 'p' && from[0] !== to[0]);
        const isCastle = nextChess.get(from)?.type === 'k' && Math.abs(from.charCodeAt(0) - to.charCodeAt(0)) === 2;

        const moveResult = nextChess.move({
          from,
          to,
          promotion: promotion || 'q',
        });

        if (!moveResult) return false;

        // Play sound
        if (nextChess.inCheck()) {
          soundService.playCheck();
        } else if (isCastle) {
          soundService.playCastle();
        } else if (isCapture) {
          soundService.playCapture();
        } else {
          soundService.playMove();
        }

        // Add increment
        if (timeControl.incrementSeconds > 0) {
          if (moveResult.color === 'w') {
            setWhiteTime((t) => t + timeControl.incrementSeconds);
          } else {
            setBlackTime((t) => t + timeControl.incrementSeconds);
          }
        }

        // Start clock on first move
        if (!isClockRunning && timeControl.initialMinutes > 0) {
          setIsClockRunning(true);
        }

        // Auto flip for 2-player pass & play if enabled
        if (gameMode === 'pvp' && settings.autoFlipOnPvp) {
          setIsFlipped(nextChess.turn() === 'b');
        }

        // Update history
        const newHistoryItem = {
          san: moveResult.san,
          from: moveResult.from,
          to: moveResult.to,
          color: moveResult.color as PieceColor,
          fenAfter: nextChess.fen(),
        };

        const updatedHistory = [...moveHistory, newHistoryItem];
        setMoveHistory(updatedHistory);
        setViewMoveIndex(updatedHistory.length - 1);
        setLiveChess(nextChess);

        verifyGameStatus(nextChess);
        return true;
      } catch (err) {
        console.error('Move error:', err);
        return false;
      }
    },
    [liveChess, moveHistory, isClockRunning, timeControl, gameMode, settings.autoFlipOnPvp, verifyGameStatus]
  );

  // Trigger AI move (ONLY on liveChess, NEVER during history view)
  useEffect(() => {
    if (gameMode !== 'ai' || liveChess.isGameOver()) return;

    const isAiTurn = liveChess.turn() !== userColor;
    if (isAiTurn && !isAiThinking) {
      setIsAiThinking(true);
      const delay = Math.random() * 300 + 200;

      const timer = setTimeout(() => {
        try {
          const historySan = moveHistory.map((m) => m.san);
          const { move } = getAIMove(liveChess.fen(), aiDifficulty, historySan);

          if (move) {
            executeMove(move.from as Square, move.to as Square, move.promotion);
          }
        } finally {
          setIsAiThinking(false);
        }
      }, delay);

      return () => clearTimeout(timer);
    }
  }, [liveChess, gameMode, userColor, aiDifficulty, isAiThinking, moveHistory, executeMove]);

  // Keyboard navigation shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;

      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        setViewMoveIndex((prev) => Math.max(-1, prev - 1));
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        setViewMoveIndex((prev) => Math.min(moveHistory.length - 1, prev + 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setViewMoveIndex(-1);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setViewMoveIndex(moveHistory.length - 1);
      } else if (e.key.toLowerCase() === 'f') {
        setIsFlipped((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [moveHistory.length]);

  // Run full game analysis report
  const handleRunAnalysis = useCallback(() => {
    if (moveHistory.length === 0) return;
    setIsAnalyzingGame(true);

    setTimeout(() => {
      try {
        const report = reviewGame(moveHistory);
        setReviewReport(report);

        setMoveHistory((prev) =>
          prev.map((item, idx) => ({
            ...item,
            analysis: report.moves[idx],
          }))
        );
        setActiveTab('analysis');
      } finally {
        setIsAnalyzingGame(false);
      }
    }, 350);
  }, [moveHistory]);

  // Jump to specific move in history
  const handleSelectMove = useCallback((index: number) => {
    setViewMoveIndex(index);
  }, []);

  // Jump back to live position
  const handleReturnToLive = useCallback(() => {
    setViewMoveIndex(moveHistory.length - 1);
  }, [moveHistory.length]);

  // Start new game
  const handleStartNewGame = useCallback(
    (config: {
      mode: GameMode;
      aiDifficulty: AIDifficulty;
      playerColor: PieceColor | 'random';
      timeControl: TimeControl;
    }) => {
      const chosenColor =
        config.playerColor === 'random'
          ? Math.random() > 0.5 ? 'w' : 'b'
          : config.playerColor;

      setGameMode(config.mode);
      setAiDifficulty(config.aiDifficulty);
      setUserColor(chosenColor);
      setIsFlipped(chosenColor === 'b');
      setTimeControl(config.timeControl);

      const sec = config.timeControl.initialMinutes * 60;
      setWhiteTime(sec);
      setBlackTime(sec);
      setIsClockRunning(false);

      const freshChess = new Chess();
      setLiveChess(freshChess);
      setMoveHistory([]);
      setViewMoveIndex(-1);
      setReviewReport(null);
      setEvalScore(0);
      setActiveTab('moves');
    },
    []
  );

  // Import PGN / FEN
  const handleImportPgn = useCallback((pgn: string): boolean => {
    try {
      const test = new Chess();
      test.loadPgn(pgn);
      setLiveChess(test);
      const history = test.history({ verbose: true });
      const newItems = history.map((m) => ({
        san: m.san,
        from: m.from,
        to: m.to,
        color: m.color as PieceColor,
        fenAfter: m.after,
      }));
      setMoveHistory(newItems);
      setViewMoveIndex(newItems.length - 1);
      setGameMode('analysis');
      return true;
    } catch {
      return false;
    }
  }, []);

  const handleImportFen = useCallback((fen: string): boolean => {
    try {
      const test = new Chess(fen);
      setLiveChess(test);
      setMoveHistory([]);
      setViewMoveIndex(-1);
      setGameMode('analysis');
      return true;
    } catch {
      return false;
    }
  }, []);

  // Save game to user profile archive
  const handleSaveGameToArchive = useCallback(
    (title: string) => {
      const pgn = liveChess.pgn();
      setProfile((prev) => ({
        ...prev,
        history: [
          {
            date: new Date().toLocaleDateString(),
            opponent: title,
            result: 'draw',
            eloChange: 0,
            pgn,
          },
          ...prev.history,
        ],
      }));
    },
    [liveChess]
  );

  // Active inspected move
  const activeMoveAnalysis =
    viewMoveIndex >= 0 && moveHistory[viewMoveIndex]?.analysis
      ? moveHistory[viewMoveIndex].analysis!
      : null;

  // Last move played
  const lastMove =
    moveHistory.length > 0 && viewMoveIndex >= 0
      ? {
          from: moveHistory[viewMoveIndex].from,
          to: moveHistory[viewMoveIndex].to,
        }
      : null;

  // Best move highlight arrow for analysis
  const bestMoveHighlight =
    activeMoveAnalysis?.bestMoveSan && activeMoveAnalysis.bestMoveUci
      ? {
          from: activeMoveAnalysis.bestMoveUci.slice(0, 2),
          to: activeMoveAnalysis.bestMoveUci.slice(2, 4),
        }
      : null;

  // Player names & avatars
  const whiteName =
    gameMode === 'ai'
      ? userColor === 'w'
        ? profile.name
        : `AI (${aiDifficulty.toUpperCase()})`
      : 'White';
  const blackName =
    gameMode === 'ai'
      ? userColor === 'b'
        ? profile.name
        : `AI (${aiDifficulty.toUpperCase()})`
      : 'Black';

  const whiteAvatar = gameMode === 'ai' && userColor === 'b' ? '🤖' : profile.avatar;
  const blackAvatar = gameMode === 'ai' && userColor === 'w' ? '🤖' : profile.avatar;

  const topColor: PieceColor = isFlipped ? 'w' : 'b';
  const bottomColor: PieceColor = isFlipped ? 'b' : 'w';

  return (
    <div
      className={`min-h-screen flex flex-col transition-colors duration-200 ${
        settings.themeMode === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'
      }`}
    >
      {/* Top Navbar */}
      <header className="sticky top-0 z-40 bg-slate-900/90 border-b border-slate-800 backdrop-blur-md px-3 sm:px-6 py-2.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo & Brand */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 text-xl font-bold">
              ♟
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-base sm:text-lg tracking-tight text-white leading-none">
                  Grandmaster Chess
                </h1>
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  STUDIO
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Tactical validation, live clocks, PGN analysis & evaluation badges
              </p>
            </div>
          </div>

          {/* Quick Header Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={() => setIsNewGameOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-sm cursor-pointer"
            >
              <Swords className="w-3.5 h-3.5" />
              <span>New Game</span>
            </button>

            <button
              onClick={() => setIsPgnOpen(true)}
              title="PGN Export & Import"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer border border-slate-700/60"
            >
              <FileText className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsProfileOpen(true)}
              title="Profile & Stats"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer border border-slate-700/60"
            >
              <span className="text-sm">{profile.avatar}</span>
              <span className="text-xs font-semibold font-mono text-emerald-400 hidden md:inline">
                {profile.elo}
              </span>
            </button>

            <button
              onClick={() => setIsSettingsOpen(true)}
              title="Settings & Themes"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer border border-slate-700/60"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Chess Arena */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-2 sm:p-4 md:p-6 flex flex-col lg:flex-row items-center lg:items-start justify-center gap-6">
        {/* Left / Center: Board & Clocks */}
        <div className="flex flex-col items-center w-full max-w-[560px] space-y-2.5">
          {/* Top Clock */}
          <ChessClock
            color={topColor}
            playerName={topColor === 'w' ? whiteName : blackName}
            avatar={topColor === 'w' ? whiteAvatar : blackAvatar}
            rating={topColor === 'w' && gameMode === 'ai' && userColor === 'w' ? profile.elo : undefined}
            timeRemainingSeconds={topColor === 'w' ? whiteTime : blackTime}
            isActive={liveChess.turn() === topColor && isClockRunning && !liveChess.isGameOver()}
            isUnlimited={timeControl.initialMinutes === 0}
            className="w-full"
          />

          {/* History Mode Floating Indicator Banner */}
          {isViewingHistory && (
            <div className="w-full bg-amber-500/20 border border-amber-500/40 rounded-xl px-3 py-1.5 flex items-center justify-between text-xs text-amber-200 animate-in fade-in duration-150">
              <div className="flex items-center gap-1.5 font-semibold">
                <Eye className="w-3.5 h-3.5" />
                <span>
                  Viewing {viewMoveIndex === -1 ? 'Initial Setup' : `Move ${viewMoveIndex + 1} of ${moveHistory.length}`}
                </span>
              </div>
              <button
                onClick={handleReturnToLive}
                className="flex items-center gap-1 bg-amber-500/30 hover:bg-amber-500/50 text-amber-100 font-bold px-2 py-0.5 rounded-lg transition-colors cursor-pointer"
              >
                <span>Jump to Live</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          )}

          {/* Mobile Eval Bar (horizontal) */}
          {settings.showEvaluationBar && (
            <div className="w-full lg:hidden px-1">
              <EvalBar
                score={evalScore}
                isWhiteBottom={!isFlipped}
                orientation="horizontal"
              />
            </div>
          )}

          {/* Desktop Eval Bar + Chessboard */}
          <div className="flex items-stretch justify-center gap-3 w-full">
            {/* Vertical Eval bar on desktop */}
            {settings.showEvaluationBar && (
              <div className="hidden lg:block shrink-0 py-1">
                <EvalBar
                  score={evalScore}
                  isWhiteBottom={!isFlipped}
                  orientation="vertical"
                />
              </div>
            )}

            {/* Chessboard */}
            <div className="flex-1 flex justify-center">
              <ChessBoard
                chess={displayChess}
                isFlipped={isFlipped}
                theme={settings.boardTheme}
                showLegalMoves={settings.showLegalMoves && !isViewingHistory}
                showCoordinates={settings.showCoordinates}
                onMakeMove={(from, to, promo) => {
                  if (isViewingHistory) {
                    handleReturnToLive();
                    return false;
                  }
                  return executeMove(from, to, promo);
                }}
                disabled={
                  liveChess.isGameOver() ||
                  (gameMode === 'ai' && liveChess.turn() !== userColor) ||
                  isAiThinking ||
                  isViewingHistory
                }
                lastMove={lastMove}
                activeAnalysisMove={activeMoveAnalysis}
                bestMoveHighlight={bestMoveHighlight}
              />
            </div>
          </div>

          {/* Bottom Clock */}
          <ChessClock
            color={bottomColor}
            playerName={bottomColor === 'w' ? whiteName : blackName}
            avatar={bottomColor === 'w' ? whiteAvatar : blackAvatar}
            rating={bottomColor === 'w' && gameMode === 'ai' && userColor === 'w' ? profile.elo : undefined}
            timeRemainingSeconds={bottomColor === 'w' ? whiteTime : blackTime}
            isActive={liveChess.turn() === bottomColor && isClockRunning && !liveChess.isGameOver()}
            isUnlimited={timeControl.initialMinutes === 0}
            className="w-full"
          />

          {/* Quick Board Toolbar */}
          <div className="w-full flex items-center justify-between px-2 text-xs text-slate-400">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsFlipped(!isFlipped)}
                title="Flip board perspective (Press F)"
                className="flex items-center gap-1 hover:text-slate-200 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Flip Board</span>
              </button>

              <button
                onClick={() => handleGameEnd(userColor === 'w' ? 'black_won' : 'white_won', 'Resignation')}
                disabled={liveChess.isGameOver() || moveHistory.length === 0}
                className="flex items-center gap-1 text-slate-400 hover:text-red-400 disabled:opacity-30 transition-colors cursor-pointer"
              >
                <Flag className="w-3.5 h-3.5" />
                <span>Resign</span>
              </button>
            </div>

            <div className="flex items-center gap-2 font-mono">
              {isAiThinking && (
                <span className="flex items-center gap-1.5 text-emerald-400 font-semibold animate-pulse">
                  <Bot className="w-3.5 h-3.5" />
                  AI calculating...
                </span>
              )}
              {!isAiThinking && (
                <span className="text-slate-400">
                  {liveChess.turn() === 'w' ? "White's turn" : "Black's turn"}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right: Move History & Game Analysis Tabs */}
        <div className="w-full max-w-[560px] lg:max-w-[420px] flex flex-col space-y-3">
          {/* Tabs bar */}
          <div className="flex bg-slate-900 border border-slate-800 rounded-xl p-1">
            <button
              onClick={() => setActiveTab('moves')}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'moves'
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Moves & Notation</span>
            </button>
            <button
              onClick={() => {
                setActiveTab('analysis');
                if (!reviewReport && moveHistory.length > 0) {
                  handleRunAnalysis();
                }
              }}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'analysis'
                  ? 'bg-slate-800 text-emerald-400 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Game Review & Badges</span>
            </button>
          </div>

          {/* Active Tab View */}
          {activeTab === 'moves' ? (
            <MoveHistory
              moves={moveHistory}
              currentMoveIndex={viewMoveIndex}
              onSelectMove={handleSelectMove}
              onResetGame={() => setIsNewGameOpen(true)}
              onExportPgn={() => setIsPgnOpen(true)}
              onFlipBoard={() => setIsFlipped(!isFlipped)}
              className="w-full"
            />
          ) : (
            <AnalysisPanel
              report={reviewReport}
              activeMove={activeMoveAnalysis}
              isAnalyzing={isAnalyzingGame}
              onRunAnalysis={handleRunAnalysis}
              onSelectMoveByBadge={(badgeKey) => {
                const foundIdx = moveHistory.findIndex((m) => m.analysis?.badge === badgeKey);
                if (foundIdx !== -1) {
                  handleSelectMove(foundIdx);
                }
              }}
              className="w-full"
            />
          )}

          {/* Status info bar */}
          <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-300">Mode:</span>
              <span className="capitalize text-emerald-400 font-medium">
                {gameMode === 'ai'
                  ? `vs AI (${aiDifficulty})`
                  : gameMode === 'pvp'
                  ? 'Local 2-Player'
                  : 'Sandbox'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-300">Clock:</span>
              <span className="text-slate-300 font-mono">{timeControl.label}</span>
            </div>
          </div>
        </div>
      </main>

      {/* Modals */}
      <NewGameModal
        isOpen={isNewGameOpen}
        onClose={() => setIsNewGameOpen(false)}
        onStartGame={handleStartNewGame}
      />

      <PgnModal
        isOpen={isPgnOpen}
        onClose={() => setIsPgnOpen(false)}
        currentPgn={liveChess.pgn()}
        onImportPgn={handleImportPgn}
        onImportFen={handleImportFen}
        onSaveGameToArchive={handleSaveGameToArchive}
      />

      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        profile={profile}
        onUpdateProfile={(updated) => setProfile((p) => ({ ...p, ...updated }))}
        onLoadArchivedGame={(pgn) => {
          handleImportPgn(pgn);
        }}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(updated) => setSettings((s) => ({ ...s, ...updated }))}
      />

      <GameOverModal
        isOpen={gameOverInfo.isOpen}
        onClose={() => setGameOverInfo((prev) => ({ ...prev, isOpen: false }))}
        result={gameOverInfo.result}
        reason={gameOverInfo.reason}
        onNewGame={() => setIsNewGameOpen(true)}
        onAnalyzeGame={() => {
          handleRunAnalysis();
          setActiveTab('analysis');
        }}
        onExportPgn={() => setIsPgnOpen(true)}
        userColor={userColor}
      />
    </div>
  );
}
