export type PieceColor = 'w' | 'b';
export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';

export type GameMode = 'pvp' | 'ai' | 'analysis';
export type AIDifficulty = 'beginner' | 'intermediate' | 'advanced' | 'master' | 'grandmaster';

export type MoveBadgeType = 
  | 'brilliant'    // !!
  | 'great'        // !
  | 'best'         // ★
  | 'excellent'    // 👍
  | 'good'         // ✓
  | 'book'         // 📖
  | 'inaccuracy'   // ?!
  | 'mistake'      // ?
  | 'miss'         // ✖
  | 'blunder'      // ??
  | 'forced'       // 👑
  | 'checkmate';   // #

export interface MoveAnalysis {
  san: string;
  from: string;
  to: string;
  color: PieceColor;
  fenBefore: string;
  fenAfter: string;
  evalBefore: number; // in pawns from mover's perspective
  evalAfter: number;
  centipawnLoss: number;
  badge: MoveBadgeType;
  commentary: string;
  bestMoveSan?: string;
  bestMoveUci?: string;
}

export interface GameReviewReport {
  whiteAccuracy: number;
  blackAccuracy: number;
  moves: MoveAnalysis[];
  badgeCounts: {
    white: Record<MoveBadgeType, number>;
    black: Record<MoveBadgeType, number>;
  };
}

export interface TimeControl {
  id: string;
  label: string;
  initialMinutes: number;
  incrementSeconds: number;
}

export interface PlayerProfile {
  id: string;
  name: string;
  avatar: string;
  elo: number;
  highestElo: number;
  gamesPlayed: number;
  wins: number;
  losses: number;
  draws: number;
  history: Array<{
    date: string;
    opponent: string;
    result: 'win' | 'loss' | 'draw';
    eloChange: number;
    pgn: string;
  }>;
}

export type BoardTheme = 'emerald' | 'wood' | 'midnight' | 'tournament' | 'cyberpunk';

export interface GameSettings {
  boardTheme: BoardTheme;
  soundEnabled: boolean;
  soundVolume: number;
  showLegalMoves: boolean;
  showEvaluationBar: boolean;
  autoFlipOnPvp: boolean;
  showCoordinates: boolean;
  themeMode: 'dark' | 'light';
}
