import React, { useState } from 'react';
import { AIDifficulty, GameMode, PieceColor, TimeControl } from '../types/chess';
import { Bot, Users, Search, Clock, Swords, X } from 'lucide-react';

interface NewGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartGame: (config: {
    mode: GameMode;
    aiDifficulty: AIDifficulty;
    playerColor: PieceColor | 'random';
    timeControl: TimeControl;
  }) => void;
}

export const TIME_CONTROLS: TimeControl[] = [
  { id: 'bullet1', label: '1 min', initialMinutes: 1, incrementSeconds: 0 },
  { id: 'bullet1_1', label: '1 | 1', initialMinutes: 1, incrementSeconds: 1 },
  { id: 'blitz3_2', label: '3 | 2', initialMinutes: 3, incrementSeconds: 2 },
  { id: 'blitz5', label: '5 min', initialMinutes: 5, incrementSeconds: 0 },
  { id: 'rapid10', label: '10 min', initialMinutes: 10, incrementSeconds: 0 },
  { id: 'rapid15_10', label: '15 | 10', initialMinutes: 15, incrementSeconds: 10 },
  { id: 'unlimited', label: 'Unlimited', initialMinutes: 0, incrementSeconds: 0 },
];

const AI_DIFFICULTIES: Array<{ id: AIDifficulty; label: string; elo: number; desc: string }> = [
  { id: 'beginner', label: 'Novice', elo: 600, desc: 'Casual, plays quickly with fun errors' },
  { id: 'intermediate', label: 'Intermediate', elo: 1200, desc: 'Knows basics, solid piece play' },
  { id: 'advanced', label: 'Advanced', elo: 1600, desc: 'Tactical awareness & positional vision' },
  { id: 'master', label: 'Master', elo: 2000, desc: 'Ruthless calculation & deep openings' },
  { id: 'grandmaster', label: 'Grandmaster', elo: 2400, desc: 'Peak engine depth & zero forgiveness' },
];

export const NewGameModal: React.FC<NewGameModalProps> = ({
  isOpen,
  onClose,
  onStartGame,
}) => {
  const [mode, setMode] = useState<GameMode>('ai');
  const [aiDifficulty, setAiDifficulty] = useState<AIDifficulty>('intermediate');
  const [playerColor, setPlayerColor] = useState<PieceColor | 'random'>('w');
  const [selectedTimeControl, setSelectedTimeControl] = useState<TimeControl>(TIME_CONTROLS[4]); // Rapid 10 min

  if (!isOpen) return null;

  const handleStart = () => {
    onStartGame({
      mode,
      aiDifficulty,
      playerColor,
      timeControl: selectedTimeControl,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Swords className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-slate-100">Start New Game</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 overflow-y-auto max-h-[80vh] scrollbar-thin scrollbar-thumb-slate-800">
          {/* Mode Selector */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Game Mode
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setMode('ai')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all cursor-pointer ${
                  mode === 'ai'
                    ? 'bg-slate-800 border-emerald-500 text-emerald-400 ring-1 ring-emerald-500/50 shadow-sm'
                    : 'bg-slate-950/50 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Bot className="w-5 h-5 mb-1" />
                <span className="text-xs font-bold">vs Computer</span>
              </button>

              <button
                onClick={() => setMode('pvp')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all cursor-pointer ${
                  mode === 'pvp'
                    ? 'bg-slate-800 border-emerald-500 text-emerald-400 ring-1 ring-emerald-500/50 shadow-sm'
                    : 'bg-slate-950/50 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Users className="w-5 h-5 mb-1" />
                <span className="text-xs font-bold">Local 2-Player</span>
              </button>

              <button
                onClick={() => setMode('analysis')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all cursor-pointer ${
                  mode === 'analysis'
                    ? 'bg-slate-800 border-emerald-500 text-emerald-400 ring-1 ring-emerald-500/50 shadow-sm'
                    : 'bg-slate-950/50 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Search className="w-5 h-5 mb-1" />
                <span className="text-xs font-bold">Sandbox</span>
              </button>
            </div>
          </div>

          {/* AI Difficulty (if vs Computer) */}
          {mode === 'ai' && (
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
                AI Difficulty Level
              </label>
              <div className="space-y-1.5">
                {AI_DIFFICULTIES.map((diff) => {
                  const isSelected = aiDifficulty === diff.id;
                  return (
                    <button
                      key={diff.id}
                      onClick={() => setAiDifficulty(diff.id)}
                      className={`w-full flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer text-left ${
                        isSelected
                          ? 'bg-slate-800 border-emerald-500 ring-1 ring-emerald-500/50'
                          : 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-slate-200">{diff.label}</span>
                        <span className="text-[10px] text-slate-400">{diff.desc}</span>
                      </div>
                      <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                        {diff.elo}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Color Selection */}
          {mode === 'ai' && (
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Play As
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => setPlayerColor('w')}
                  className={`flex items-center justify-center gap-2 py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    playerColor === 'w'
                      ? 'bg-slate-800 border-emerald-500 text-emerald-400 shadow-sm'
                      : 'bg-slate-950/50 border-slate-800 text-slate-400'
                  }`}
                >
                  <span className="w-3 h-3 rounded-full bg-white border border-slate-900 inline-block" />
                  <span>White</span>
                </button>

                <button
                  onClick={() => setPlayerColor('random')}
                  className={`flex items-center justify-center gap-2 py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    playerColor === 'random'
                      ? 'bg-slate-800 border-emerald-500 text-emerald-400 shadow-sm'
                      : 'bg-slate-950/50 border-slate-800 text-slate-400'
                  }`}
                >
                  <span>🎲 Random</span>
                </button>

                <button
                  onClick={() => setPlayerColor('b')}
                  className={`flex items-center justify-center gap-2 py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    playerColor === 'b'
                      ? 'bg-slate-800 border-emerald-500 text-emerald-400 shadow-sm'
                      : 'bg-slate-950/50 border-slate-800 text-slate-400'
                  }`}
                >
                  <span className="w-3 h-3 rounded-full bg-slate-900 border border-slate-500 inline-block" />
                  <span>Black</span>
                </button>
              </div>
            </div>
          )}

          {/* Time Controls */}
          {mode !== 'analysis' && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  Timer / Clock
                </label>
                <Clock className="w-3.5 h-3.5 text-slate-500" />
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5">
                {TIME_CONTROLS.map((tc) => {
                  const isSelected = selectedTimeControl.id === tc.id;
                  return (
                    <button
                      key={tc.id}
                      onClick={() => setSelectedTimeControl(tc)}
                      className={`py-2 px-1 rounded-xl border text-xs font-semibold transition-all cursor-pointer text-center ${
                        isSelected
                          ? 'bg-slate-800 border-emerald-500 text-emerald-400 shadow-sm'
                          : 'bg-slate-950/50 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {tc.label}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Action button */}
          <button
            onClick={handleStart}
            className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-md transition-all cursor-pointer mt-2"
          >
            Play Now
          </button>
        </div>
      </div>
    </div>
  );
};
