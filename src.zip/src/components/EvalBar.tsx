import React from 'react';

interface EvalBarProps {
  score: number; // in pawns from White's perspective (+ white, - black)
  isWhiteBottom?: boolean;
  orientation?: 'vertical' | 'horizontal';
  className?: string;
}

export const EvalBar: React.FC<EvalBarProps> = ({
  score,
  isWhiteBottom = true,
  orientation = 'vertical',
  className = '',
}) => {
  // Convert pawn score to percentage [0..100] for White
  // +5 pawns = ~95%, 0 = 50%, -5 = ~5%
  let whitePercent = 50;
  let label = '0.0';

  if (Math.abs(score) > 200) {
    // Checkmate state
    if (score > 0) {
      whitePercent = 100;
      label = 'M';
    } else {
      whitePercent = 0;
      label = '-M';
    }
  } else {
    // Sigmoid curve mapping
    const winProb = 1 / (1 + Math.pow(10, -score / 4));
    whitePercent = Math.max(5, Math.min(95, Math.round(winProb * 100)));
    const rounded = Math.abs(score).toFixed(1);
    label = score > 0 ? `+${rounded}` : score < 0 ? `-${rounded}` : '0.0';
  }

  // If flipped, reverse orientation
  const barWhiteFill = isWhiteBottom ? whitePercent : 100 - whitePercent;

  if (orientation === 'horizontal') {
    return (
      <div className={`w-full flex items-center gap-2 ${className}`}>
        <div className="relative flex-1 h-3.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700/60 shadow-inner">
          <div
            className="h-full bg-white transition-all duration-300 ease-out"
            style={{ width: `${barWhiteFill}%` }}
          />
          <div className="absolute inset-0 flex items-center justify-between px-2 text-[9px] font-mono font-bold pointer-events-none">
            <span className={barWhiteFill > 50 ? 'text-slate-900' : 'text-slate-200'}>W</span>
            <span className={barWhiteFill > 50 ? 'text-slate-200' : 'text-slate-900'}>B</span>
          </div>
        </div>
        <span className="text-xs font-mono font-semibold text-slate-300 w-12 text-right shrink-0">
          {label}
        </span>
      </div>
    );
  }

  return (
    <div className={`relative flex flex-col items-center select-none ${className}`}>
      {/* Vertical eval bar */}
      <div className="relative w-7 h-full min-h-[300px] max-h-[640px] bg-slate-900 rounded-lg overflow-hidden border border-slate-700/80 shadow-md flex flex-col justify-end">
        {/* White portion fills from bottom up if isWhiteBottom is true */}
        <div
          className="w-full bg-slate-100 transition-all duration-300 ease-out flex items-center justify-center relative"
          style={{ height: `${barWhiteFill}%` }}
        >
          {barWhiteFill >= 20 && (
            <span className="absolute bottom-1.5 text-[10px] font-mono font-bold text-slate-800 tracking-tighter">
              {label}
            </span>
          )}
        </div>

        {/* When White fill is small, display label at top in black bar */}
        {barWhiteFill < 20 && (
          <span className="absolute top-1.5 inset-x-0 text-center text-[10px] font-mono font-bold text-slate-200 tracking-tighter">
            {label}
          </span>
        )}
      </div>
    </div>
  );
};
