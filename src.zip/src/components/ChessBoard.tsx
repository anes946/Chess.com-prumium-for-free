import React, { useState } from 'react';
import { Chess, Square, PieceSymbol, Color } from 'chess.js';
import { BoardTheme, MoveAnalysis, PieceColor, PieceType } from '../types/chess';
import { ChessPieceIcon } from '../utils/chessPieces';
import { AnalysisBadge } from './AnalysisBadge';

interface ChessBoardProps {
  chess: Chess;
  isFlipped: boolean;
  theme: BoardTheme;
  showLegalMoves: boolean;
  showCoordinates: boolean;
  onMakeMove: (from: Square, to: Square, promotion?: string) => boolean;
  disabled?: boolean;
  lastMove?: { from: string; to: string } | null;
  activeAnalysisMove?: MoveAnalysis | null;
  bestMoveHighlight?: { from: string; to: string } | null;
}

const THEME_STYLES: Record<
  BoardTheme,
  { light: string; dark: string; border: string; labelLight: string; labelDark: string }
> = {
  emerald: {
    light: '#edeed1',
    dark: '#779952',
    border: '#455d28',
    labelLight: '#779952',
    labelDark: '#edeed1',
  },
  wood: {
    light: '#f0d9b5',
    dark: '#b58863',
    border: '#6f4f34',
    labelLight: '#b58863',
    labelDark: '#f0d9b5',
  },
  midnight: {
    light: '#cbd5e1',
    dark: '#475569',
    border: '#1e293b',
    labelLight: '#475569',
    labelDark: '#cbd5e1',
  },
  tournament: {
    light: '#dee3e6',
    dark: '#4a7c9d',
    border: '#2c4b60',
    labelLight: '#4a7c9d',
    labelDark: '#dee3e6',
  },
  cyberpunk: {
    light: '#1e293b',
    dark: '#581c87',
    border: '#8b5cf6',
    labelLight: '#a855f7',
    labelDark: '#38bdf8',
  },
};

export const ChessBoard: React.FC<ChessBoardProps> = ({
  chess,
  isFlipped,
  theme,
  showLegalMoves,
  showCoordinates,
  onMakeMove,
  disabled = false,
  lastMove,
  activeAnalysisMove,
  bestMoveHighlight,
}) => {
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [legalMoves, setLegalMoves] = useState<Square[]>([]);
  const [pendingPromotion, setPendingPromotion] = useState<{ from: Square; to: Square } | null>(null);
  const [draggedSquare, setDraggedSquare] = useState<Square | null>(null);

  const themeStyle = THEME_STYLES[theme] || THEME_STYLES.emerald;
  const board = chess.board();

  // Find King in check square if in check
  let checkSquare: Square | null = null;
  if (chess.inCheck()) {
    const turn = chess.turn();
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (piece && piece.type === 'k' && piece.color === turn) {
          const file = String.fromCharCode('a'.charCodeAt(0) + c);
          const rank = 8 - r;
          checkSquare = `${file}${rank}` as Square;
        }
      }
    }
  }

  // Calculate ranks and files order based on isFlipped
  const ranks = isFlipped ? [1, 2, 3, 4, 5, 6, 7, 8] : [8, 7, 6, 5, 4, 3, 2, 1];
  const files = isFlipped ? ['h', 'g', 'f', 'e', 'd', 'c', 'b', 'a'] : ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

  const getLegalDestinations = (sq: Square): Square[] => {
    return chess
      .moves({ square: sq, verbose: true })
      .map((m) => m.to as Square);
  };

  const handleSquareClick = (sq: Square) => {
    if (disabled || pendingPromotion) return;

    // If already selected, try to move
    if (selectedSquare) {
      if (selectedSquare === sq) {
        setSelectedSquare(null);
        setLegalMoves([]);
        return;
      }

      if (legalMoves.includes(sq)) {
        // Check if move is a pawn promotion
        const piece = chess.get(selectedSquare);
        const isPromotion =
          piece?.type === 'p' &&
          ((piece.color === 'w' && sq.endsWith('8')) || (piece.color === 'b' && sq.endsWith('1')));

        if (isPromotion) {
          setPendingPromotion({ from: selectedSquare, to: sq });
          return;
        }

        const success = onMakeMove(selectedSquare, sq);
        setSelectedSquare(null);
        setLegalMoves([]);
        return;
      }
    }

    // Select piece if it's the current player's piece
    const piece = chess.get(sq);
    if (piece && piece.color === chess.turn()) {
      setSelectedSquare(sq);
      const dests = showLegalMoves ? getLegalDestinations(sq) : [];
      setLegalMoves(dests);
    } else {
      setSelectedSquare(null);
      setLegalMoves([]);
    }
  };

  // Drag and Drop handlers
  const handleDragStart = (e: React.DragEvent, sq: Square) => {
    if (disabled || pendingPromotion) {
      e.preventDefault();
      return;
    }
    const piece = chess.get(sq);
    if (!piece || piece.color !== chess.turn()) {
      e.preventDefault();
      return;
    }
    setDraggedSquare(sq);
    setSelectedSquare(sq);
    if (showLegalMoves) {
      setLegalMoves(getLegalDestinations(sq));
    }
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', sq);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, targetSquare: Square) => {
    e.preventDefault();
    const sourceSquare = draggedSquare || (e.dataTransfer.getData('text/plain') as Square);
    setDraggedSquare(null);

    if (!sourceSquare || sourceSquare === targetSquare) return;

    const piece = chess.get(sourceSquare);
    const isPromotion =
      piece?.type === 'p' &&
      ((piece.color === 'w' && targetSquare.endsWith('8')) ||
        (piece.color === 'b' && targetSquare.endsWith('1')));

    if (isPromotion) {
      setPendingPromotion({ from: sourceSquare, to: targetSquare });
      return;
    }

    const dests = getLegalDestinations(sourceSquare);
    if (dests.includes(targetSquare)) {
      onMakeMove(sourceSquare, targetSquare);
      setSelectedSquare(null);
      setLegalMoves([]);
    }
  };

  const handleSelectPromotion = (pieceType: string) => {
    if (!pendingPromotion) return;
    onMakeMove(pendingPromotion.from, pendingPromotion.to, pieceType);
    setPendingPromotion(null);
    setSelectedSquare(null);
    setLegalMoves([]);
  };

  return (
    <div className="relative w-full max-w-[560px] aspect-square rounded-2xl p-2 sm:p-2.5 shadow-2xl bg-slate-900 border border-slate-800 transition-all">
      {/* 8x8 Grid */}
      <div className="w-full h-full grid grid-cols-8 grid-rows-8 rounded-xl overflow-hidden shadow-inner select-none relative">
        {ranks.map((rank, rankIdx) =>
          files.map((file, fileIdx) => {
            const square = `${file}${rank}` as Square;
            const isLight = (fileIdx + rankIdx) % 2 === (isFlipped ? 1 : 0);
            const piece = chess.get(square);
            const isSelected = selectedSquare === square;
            const isLegalDest = legalMoves.includes(square);
            const isLastMove = lastMove?.from === square || lastMove?.to === square;
            const isCheck = checkSquare === square;
            const isBestMoveSource = bestMoveHighlight?.from === square;
            const isBestMoveTarget = bestMoveHighlight?.to === square;
            const isAnalysisTarget = activeAnalysisMove?.to === square;

            return (
              <div
                key={square}
                onClick={() => handleSquareClick(square)}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, square)}
                className="relative flex items-center justify-center transition-colors duration-75 cursor-pointer"
                style={{
                  backgroundColor: isLight ? themeStyle.light : themeStyle.dark,
                }}
              >
                {/* Last move highlight */}
                {isLastMove && (
                  <div className="absolute inset-0 bg-yellow-400/35 pointer-events-none" />
                )}

                {/* Best move hint highlight */}
                {isBestMoveSource && (
                  <div className="absolute inset-0 bg-emerald-500/35 pointer-events-none border-2 border-dashed border-emerald-400/80" />
                )}
                {isBestMoveTarget && (
                  <div className="absolute inset-0 bg-emerald-500/40 pointer-events-none border-2 border-emerald-400" />
                )}

                {/* Selected square highlight */}
                {isSelected && (
                  <div className="absolute inset-0 bg-emerald-500/40 pointer-events-none border-2 border-emerald-400 shadow-inner" />
                )}

                {/* King in Check red warning glow */}
                {isCheck && (
                  <div className="absolute inset-0 bg-red-600/50 pointer-events-none animate-pulse rounded-sm shadow-[inset_0_0_12px_rgba(239,68,68,0.8)]" />
                )}

                {/* Coordinates labels */}
                {showCoordinates && (
                  <>
                    {/* Rank number on the first column of the board */}
                    {fileIdx === 0 && (
                      <span
                        className="absolute top-0.5 left-1 text-[10px] sm:text-xs font-bold leading-none pointer-events-none select-none font-mono"
                        style={{ color: isLight ? themeStyle.labelLight : themeStyle.labelDark }}
                      >
                        {rank}
                      </span>
                    )}
                    {/* File letter on the bottom row of the board */}
                    {rankIdx === 7 && (
                      <span
                        className="absolute bottom-0.5 right-1 text-[10px] sm:text-xs font-bold leading-none pointer-events-none select-none font-mono uppercase"
                        style={{ color: isLight ? themeStyle.labelLight : themeStyle.labelDark }}
                      >
                        {file}
                      </span>
                    )}
                  </>
                )}

                {/* Legal Move indicator dots / capture rings */}
                {isLegalDest && !piece && (
                  <div className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-slate-900/30 dark:bg-black/35 pointer-events-none transform scale-100 hover:scale-125 transition-transform" />
                )}
                {isLegalDest && piece && (
                  <div className="absolute inset-1 rounded-full border-4 border-slate-900/35 dark:border-black/40 pointer-events-none" />
                )}

                {/* Chess Piece */}
                {piece && (
                  <div
                    draggable={!disabled && piece.color === chess.turn()}
                    onDragStart={(e) => handleDragStart(e, square)}
                    className="w-[88%] h-[88%] flex items-center justify-center cursor-grab active:cursor-grabbing hover:scale-105 active:scale-95 transition-transform duration-75 relative z-10 drop-shadow-md"
                  >
                    <ChessPieceIcon
                      type={piece.type as PieceType}
                      color={piece.color as PieceColor}
                    />
                  </div>
                )}

                {/* Move Analysis Mark Badge (from image.png) on the destination square */}
                {isAnalysisTarget && activeAnalysisMove && (
                  <div className="absolute top-0.5 right-0.5 z-20 pointer-events-none animate-in fade-in zoom-in duration-200">
                    <AnalysisBadge badge={activeAnalysisMove.badge} size="sm" />
                  </div>
                )}
              </div>
            );
          })
        )}

        {/* Pawn Promotion Modal overlay */}
        {pendingPromotion && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center z-50 animate-in fade-in duration-150 p-4">
            <div className="bg-slate-900 border border-slate-700 rounded-2xl p-4 shadow-2xl flex flex-col items-center gap-3">
              <span className="text-sm font-bold text-slate-100">Promote Pawn</span>
              <div className="flex gap-2">
                {[
                  { type: 'q', label: 'Queen' },
                  { type: 'r', label: 'Rook' },
                  { type: 'b', label: 'Bishop' },
                  { type: 'n', label: 'Knight' },
                ].map((item) => (
                  <button
                    key={item.type}
                    onClick={() => handleSelectPromotion(item.type)}
                    className="w-14 h-14 sm:w-16 sm:h-16 p-2 rounded-xl bg-slate-800 hover:bg-emerald-600/30 hover:border-emerald-500 border border-slate-700 flex flex-col items-center justify-center transition-all cursor-pointer group"
                    title={item.label}
                  >
                    <div className="w-10 h-10 group-hover:scale-110 transition-transform">
                      <ChessPieceIcon
                        type={item.type as PieceType}
                        color={chess.turn() as PieceColor}
                      />
                    </div>
                  </button>
                ))}
              </div>
              <button
                onClick={() => setPendingPromotion(null)}
                className="text-xs text-slate-400 hover:text-slate-200 mt-1 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
