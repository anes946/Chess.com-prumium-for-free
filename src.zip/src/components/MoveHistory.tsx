import React, { useRef, useEffect } from 'react';
import { MoveAnalysis, PieceColor } from '../types/chess';
import { AnalysisBadge } from './AnalysisBadge';
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  RotateCcw,
  Play,
  Pause,
  Download,
} from 'lucide-react';

interface HistoryMoveItem {
  san: string;
  from: string;
  to: string;
  color: PieceColor;
  analysis?: MoveAnalysis;
}

interface MoveHistoryProps {
  moves: HistoryMoveItem[];
  currentMoveIndex: number; // -1 for start of game, 0..moves.length-1
  onSelectMove: (index: number) => void;
  onResetGame: () => void;
  onExportPgn: () => void;
  onFlipBoard: () => void;
  className?: string;
}

export const MoveHistory: React.FC<MoveHistoryProps> = ({
  moves,
  currentMoveIndex,
  onSelectMove,
  onResetGame,
  onExportPgn,
  onFlipBoard,
  className = '',
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPlayingReplay, setIsPlayingReplay] = React.useState(false);

  // Auto-scroll to current move
  useEffect(() => {
    if (scrollRef.current) {
      const activeEl = scrollRef.current.querySelector('[data-active="true"]');
      if (activeEl) {
        activeEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }
  }, [currentMoveIndex]);

  // Auto-play replay timer
  useEffect(() => {
    let interval: any;
    if (isPlayingReplay) {
      interval = setInterval(() => {
        if (currentMoveIndex < moves.length - 1) {
          onSelectMove(currentMoveIndex + 1);
        } else {
          setIsPlayingReplay(false);
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlayingReplay, currentMoveIndex, moves.length, onSelectMove]);

  // Group moves into turn pairs: [ { moveNum: 1, white: ..., black: ... } ]
  const pairs: Array<{
    turn: number;
    whiteIndex: number;
    whiteMove?: HistoryMoveItem;
    blackIndex?: number;
    blackMove?: HistoryMoveItem;
  }> = [];

  for (let i = 0; i < moves.length; i += 2) {
    const turn = Math.floor(i / 2) + 1;
    pairs.push({
      turn,
      whiteIndex: i,
      whiteMove: moves[i],
      blackIndex: i + 1 < moves.length ? i + 1 : undefined,
      blackMove: i + 1 < moves.length ? moves[i + 1] : undefined,
    });
  }

  return (
    <div
      className={`flex flex-col bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl ${className}`}
    >
      {/* Header bar */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/90">
        <div className="flex items-center gap-2">
          <span className="font-bold text-sm text-slate-100">Move Log</span>
          <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700/60">
            {moves.length} {moves.length === 1 ? 'ply' : 'plies'}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={onFlipBoard}
            title="Flip Board Perspective"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={onExportPgn}
            title="Export PGN"
            className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Move pairs table */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto max-h-[320px] p-2 space-y-0.5 text-sm font-mono scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent"
      >
        {pairs.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-slate-500 text-xs text-center p-4">
            <span>No moves made yet</span>
            <span className="text-[11px] text-slate-600 mt-1">Make a move to start recording</span>
          </div>
        ) : (
          pairs.map((pair) => (
            <div
              key={pair.turn}
              className="grid grid-cols-[38px_1fr_1fr] items-center gap-1.5 px-2 py-1 rounded-lg hover:bg-slate-800/40 transition-colors text-xs"
            >
              {/* Turn number */}
              <span className="text-slate-500 font-medium">{pair.turn}.</span>

              {/* White move */}
              {pair.whiteMove && (
                <button
                  data-active={currentMoveIndex === pair.whiteIndex}
                  onClick={() => onSelectMove(pair.whiteIndex)}
                  className={`flex items-center justify-between px-2 py-1 rounded-md transition-all text-left cursor-pointer ${
                    currentMoveIndex === pair.whiteIndex
                      ? 'bg-emerald-600/30 text-emerald-300 font-bold border border-emerald-500/50 shadow-xs'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span className="font-semibold">{pair.whiteMove.san}</span>
                  {pair.whiteMove.analysis && (
                    <AnalysisBadge badge={pair.whiteMove.analysis.badge} size="xs" />
                  )}
                </button>
              )}

              {/* Black move */}
              {pair.blackMove && pair.blackIndex !== undefined ? (
                <button
                  data-active={currentMoveIndex === pair.blackIndex}
                  onClick={() => onSelectMove(pair.blackIndex!)}
                  className={`flex items-center justify-between px-2 py-1 rounded-md transition-all text-left cursor-pointer ${
                    currentMoveIndex === pair.blackIndex
                      ? 'bg-emerald-600/30 text-emerald-300 font-bold border border-emerald-500/50 shadow-xs'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span className="font-semibold">{pair.blackMove.san}</span>
                  {pair.blackMove.analysis && (
                    <AnalysisBadge badge={pair.blackMove.analysis.badge} size="xs" />
                  )}
                </button>
              ) : (
                <div />
              )}
            </div>
          ))
        )}
      </div>

      {/* Navigation controls */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-950/60 border-t border-slate-800">
        <button
          onClick={() => onSelectMove(-1)}
          disabled={currentMoveIndex === -1}
          title="Start of game"
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 disabled:opacity-30 disabled:hover:text-slate-400 hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <ChevronsLeft className="w-4 h-4" />
        </button>

        <button
          onClick={() => onSelectMove(Math.max(-1, currentMoveIndex - 1))}
          disabled={currentMoveIndex === -1}
          title="Previous move"
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 disabled:opacity-30 disabled:hover:text-slate-400 hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <button
          onClick={() => setIsPlayingReplay(!isPlayingReplay)}
          disabled={moves.length === 0}
          title={isPlayingReplay ? 'Pause auto-play' : 'Play replay'}
          className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-emerald-400 hover:bg-slate-700/80 transition-colors flex items-center gap-1.5 text-xs font-semibold cursor-pointer disabled:opacity-30"
        >
          {isPlayingReplay ? (
            <>
              <Pause className="w-3.5 h-3.5" />
              <span>Pause</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Replay</span>
            </>
          )}
        </button>

        <button
          onClick={() => onSelectMove(Math.min(moves.length - 1, currentMoveIndex + 1))}
          disabled={currentMoveIndex === moves.length - 1}
          title="Next move"
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 disabled:opacity-30 disabled:hover:text-slate-400 hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <ChevronRight className="w-4 h-4" />
        </button>

        <button
          onClick={() => onSelectMove(moves.length - 1)}
          disabled={currentMoveIndex === moves.length - 1}
          title="Current position"
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 disabled:opacity-30 disabled:hover:text-slate-400 hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <ChevronsRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
