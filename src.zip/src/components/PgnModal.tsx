import React, { useState } from 'react';
import { Copy, Check, Download, Upload, X, FileText, Bookmark } from 'lucide-react';

interface PgnModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPgn: string;
  onImportPgn: (pgn: string) => boolean;
  onImportFen: (fen: string) => boolean;
  onSaveGameToArchive: (title: string) => void;
}

export const PgnModal: React.FC<PgnModalProps> = ({
  isOpen,
  onClose,
  currentPgn,
  onImportPgn,
  onImportFen,
  onSaveGameToArchive,
}) => {
  const [copied, setCopied] = useState(false);
  const [importText, setImportText] = useState('');
  const [saveTitle, setSaveTitle] = useState('');
  const [activeTab, setActiveTab] = useState<'export' | 'import' | 'save'>('export');
  const [statusMessage, setStatusMessage] = useState<{ text: string; isError: boolean } | null>(null);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentPgn);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([currentPgn], { type: 'application/x-chess-pgn' });
    element.href = URL.createObjectURL(file);
    element.download = `chess_game_${new Date().toISOString().slice(0, 10)}.pgn`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleImport = () => {
    setStatusMessage(null);
    const trimmed = importText.trim();
    if (!trimmed) {
      setStatusMessage({ text: 'Please enter a valid PGN or FEN string.', isError: true });
      return;
    }

    // Try FEN first if looks like single line board
    if (trimmed.split(' ').length >= 4 && !trimmed.includes('[Event')) {
      const ok = onImportFen(trimmed);
      if (ok) {
        setStatusMessage({ text: 'FEN position loaded successfully!', isError: false });
        setTimeout(() => onClose(), 800);
        return;
      }
    }

    // Otherwise try PGN
    const ok = onImportPgn(trimmed);
    if (ok) {
      setStatusMessage({ text: 'PGN game loaded successfully!', isError: false });
      setTimeout(() => onClose(), 800);
    } else {
      setStatusMessage({ text: 'Invalid PGN or FEN notation. Please verify input.', isError: true });
    }
  };

  const handleSave = () => {
    if (!saveTitle.trim()) {
      setStatusMessage({ text: 'Please enter a name for this game.', isError: true });
      return;
    }
    onSaveGameToArchive(saveTitle.trim());
    setStatusMessage({ text: 'Game saved to your profile archive!', isError: false });
    setTimeout(() => onClose(), 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-slate-100">PGN & Game Records</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-800 bg-slate-950/50">
          <button
            onClick={() => {
              setActiveTab('export');
              setStatusMessage(null);
            }}
            className={`flex-1 py-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'export'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Export PGN
          </button>
          <button
            onClick={() => {
              setActiveTab('import');
              setStatusMessage(null);
            }}
            className={`flex-1 py-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'import'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Import PGN / FEN
          </button>
          <button
            onClick={() => {
              setActiveTab('save');
              setStatusMessage(null);
            }}
            className={`flex-1 py-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'save'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Save to Profile
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {activeTab === 'export' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Portable Game Notation (PGN) format</span>
                <span>{currentPgn.length} chars</span>
              </div>
              <textarea
                readOnly
                value={currentPgn}
                rows={7}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-xs text-slate-300 focus:outline-none resize-none selection:bg-emerald-500/30"
              />
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleCopy}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'Copied to Clipboard!' : 'Copy PGN'}</span>
                </button>
                <button
                  onClick={handleDownload}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors cursor-pointer shadow-sm"
                >
                  <Download className="w-4 h-4" />
                  <span>Download .pgn File</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'import' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-400">
                Paste PGN text or FEN string below to load the board position or full game.
              </p>
              <textarea
                value={importText}
                onChange={(e) => setImportText(e.target.value)}
                placeholder="Paste PGN (e.g. 1. e4 e5 2. Nf3...) or FEN (rnbqkbnr/pppppppp/...)"
                rows={7}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-xs text-slate-200 placeholder:text-slate-600 focus:border-emerald-500 focus:outline-none resize-none"
              />
              <button
                onClick={handleImport}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Load Game / Position</span>
              </button>
            </div>
          )}

          {activeTab === 'save' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-400">
                Save this match to your personal profile archive so you can replay it or analyze it anytime.
              </p>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Game Title</label>
                <input
                  type="text"
                  value={saveTitle}
                  onChange={(e) => setSaveTitle(e.target.value)}
                  placeholder="e.g. Italian Game vs Computer Master"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 font-sans text-xs text-slate-200 placeholder:text-slate-600 focus:border-emerald-500 focus:outline-none"
                />
              </div>
              <button
                onClick={handleSave}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <Bookmark className="w-4 h-4" />
                <span>Save to Profile Archive</span>
              </button>
            </div>
          )}

          {/* Feedback message */}
          {statusMessage && (
            <div
              className={`p-2.5 rounded-xl text-xs font-medium text-center ${
                statusMessage.isError
                  ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                  : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              }`}
            >
              {statusMessage.text}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
