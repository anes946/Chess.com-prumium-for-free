import React from 'react';
import { GameReviewReport, MoveAnalysis, MoveBadgeType } from '../types/chess';
import { AnalysisBadge, BADGE_CONFIG } from './AnalysisBadge';
import { Sparkles, Trophy, Lightbulb, CheckCircle2, TrendingUp, AlertTriangle } from 'lucide-react';

interface AnalysisPanelProps {
  report: GameReviewReport | null;
  activeMove: MoveAnalysis | null;
  isAnalyzing: boolean;
  onRunAnalysis: () => void;
  onSelectMoveByBadge?: (badge: MoveBadgeType) => void;
  className?: string;
}

const BADGE_ORDER: MoveBadgeType[] = [
  'brilliant',
  'great',
  'best',
  'excellent',
  'good',
  'book',
  'inaccuracy',
  'mistake',
  'miss',
  'blunder',
  'forced',
  'checkmate',
];

export const AnalysisPanel: React.FC<AnalysisPanelProps> = ({
  report,
  activeMove,
  isAnalyzing,
  onRunAnalysis,
  onSelectMoveByBadge,
  className = '',
}) => {
  return (
    <div
      className={`flex flex-col bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl ${className}`}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/90">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span className="font-bold text-sm text-slate-100">Game Analysis</span>
        </div>
        <button
          onClick={onRunAnalysis}
          disabled={isAnalyzing}
          className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
        >
          {isAnalyzing ? (
            <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <Sparkles className="w-3.5 h-3.5" />
          )}
          <span>{report ? 'Re-Analyze' : 'Analyze Game'}</span>
        </button>
      </div>

      <div className="p-4 space-y-4 overflow-y-auto max-h-[460px] scrollbar-thin scrollbar-thumb-slate-800">
        {/* Active move breakdown card */}
        {activeMove ? (
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AnalysisBadge badge={activeMove.badge} size="md" />
                <span className="font-bold text-sm text-slate-100">
                  {activeMove.color === 'w' ? 'White' : 'Black'} played {activeMove.san}
                </span>
              </div>
              <span
                className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                  activeMove.centipawnLoss <= 25
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : activeMove.centipawnLoss <= 120
                    ? 'bg-amber-500/20 text-amber-300'
                    : 'bg-red-500/20 text-red-300'
                }`}
              >
                {activeMove.centipawnLoss <= 5
                  ? 'Optimal'
                  : `-${(activeMove.centipawnLoss / 100).toFixed(1)} pawns`}
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {activeMove.commentary}
            </p>

            {activeMove.bestMoveSan && activeMove.bestMoveSan !== activeMove.san && (
              <div className="flex items-center gap-2 bg-emerald-950/40 border border-emerald-800/40 rounded-lg px-2.5 py-1.5 text-xs text-emerald-300">
                <Lightbulb className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>
                  Engine recommended: <strong className="font-mono text-emerald-200">{activeMove.bestMoveSan}</strong>
                </span>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-3 text-xs text-slate-400 text-center">
            Click on any move in the history log to inspect its tactical evaluation.
          </div>
        )}

        {/* Report Overview */}
        {report ? (
          <div className="space-y-4">
            {/* Accuracy Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-3 flex flex-col items-center justify-center text-center">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  White Accuracy
                </span>
                <span className="text-2xl font-black font-mono text-slate-100 mt-0.5">
                  {report.whiteAccuracy}%
                </span>
                <div className="w-full bg-slate-700/50 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className="h-full bg-emerald-400 rounded-full"
                    style={{ width: `${report.whiteAccuracy}%` }}
                  />
                </div>
              </div>

              <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-3 flex flex-col items-center justify-center text-center">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Black Accuracy
                </span>
                <span className="text-2xl font-black font-mono text-slate-100 mt-0.5">
                  {report.blackAccuracy}%
                </span>
                <div className="w-full bg-slate-700/50 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className="h-full bg-emerald-400 rounded-full"
                    style={{ width: `${report.blackAccuracy}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Badges breakdown table matching image.png */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 px-2 uppercase tracking-wider">
                <span>White</span>
                <span>Move Classification</span>
                <span>Black</span>
              </div>

              <div className="bg-slate-950/60 border border-slate-800 rounded-xl divide-y divide-slate-800/70 overflow-hidden">
                {BADGE_ORDER.map((badgeKey) => {
                  const config = BADGE_CONFIG[badgeKey];
                  const whiteCount = report.badgeCounts.white[badgeKey] || 0;
                  const blackCount = report.badgeCounts.black[badgeKey] || 0;

                  // Skip empty badge rows if both are 0 to keep UI tidy
                  if (whiteCount === 0 && blackCount === 0) return null;

                  return (
                    <div
                      key={badgeKey}
                      onClick={() => onSelectMoveByBadge && onSelectMoveByBadge(badgeKey)}
                      className="grid grid-cols-[40px_1fr_40px] items-center px-3 py-1.5 text-xs hover:bg-slate-800/40 transition-colors cursor-pointer group"
                    >
                      <span className="font-mono font-bold text-left text-slate-200">
                        {whiteCount}
                      </span>

                      <div className="flex items-center justify-center gap-2">
                        <AnalysisBadge badge={badgeKey} size="xs" />
                        <span className="font-semibold text-slate-300 group-hover:text-emerald-400 transition-colors">
                          {config.label}
                        </span>
                      </div>

                      <span className="font-mono font-bold text-right text-slate-200">
                        {blackCount}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-6 text-center space-y-2">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="text-sm font-semibold text-slate-200">Position Evaluation Ready</span>
            <p className="text-xs text-slate-400 max-w-[240px]">
              Hit <strong className="text-emerald-300">Analyze Game</strong> to calculate accuracy, discover brilliant moves, and find blunders!
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
