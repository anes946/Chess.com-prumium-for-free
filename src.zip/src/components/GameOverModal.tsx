import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, RotateCcw, Sparkles, Download, X } from 'lucide-react';
import { PieceColor } from '../types/chess';

interface GameOverModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: 'white_won' | 'black_won' | 'draw';
  reason: string;
  onNewGame: () => void;
  onAnalyzeGame: () => void;
  onExportPgn: () => void;
  userColor?: PieceColor;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  isOpen,
  onClose,
  result,
  reason,
  onNewGame,
  onAnalyzeGame,
  onExportPgn,
  userColor = 'w',
}) => {
  useEffect(() => {
    if (isOpen) {
      const isVictory =
        (result === 'white_won' && userColor === 'w') ||
        (result === 'black_won' && userColor === 'b');

      if (isVictory) {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      }
    }
  }, [isOpen, result, userColor]);

  if (!isOpen) return null;

  const title =
    result === 'white_won'
      ? 'White Wins!'
      : result === 'black_won'
      ? 'Black Wins!'
      : 'Game Drawn!';

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm shadow-2xl p-6 text-center space-y-4 relative">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-slate-500 hover:text-slate-300 p-1.5 rounded-lg cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
          <Trophy className="w-7 h-7" />
        </div>

        <div>
          <h3 className="text-xl font-black text-slate-100">{title}</h3>
          <p className="text-xs text-slate-400 mt-1 capitalize">{reason}</p>
        </div>

        <div className="space-y-2 pt-2">
          <button
            onClick={() => {
              onClose();
              onAnalyzeGame();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors shadow-md cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Game Review & Move Analysis</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onNewGame();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Rematch / New Game</span>
          </button>

          <button
            onClick={onExportPgn}
            className="w-full flex items-center justify-center gap-2 py-2 rounded-xl text-slate-400 hover:text-slate-200 text-xs font-semibold hover:bg-slate-800/60 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export PGN File</span>
          </button>
        </div>
      </div>
    </div>
  );
};
