import React from 'react';
import { MoveBadgeType } from '../types/chess';

interface AnalysisBadgeProps {
  badge: MoveBadgeType;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  className?: string;
}

export const BADGE_CONFIG: Record<
  MoveBadgeType,
  {
    type: 'text' | 'svg';
    text?: string;
    label: string;
    bgClass: string;
    textClass: string;
    borderClass: string;
    description: string;
  }
> = {
  brilliant: {
    type: 'text',
    text: '!!',
    label: 'Brilliant',
    bgClass: 'bg-[#1baaa4]',
    textClass: 'text-white',
    borderClass: 'border-[#148984]',
    description: 'A brilliant move sacrificing material for a decisive tactical attack.',
  },
  great: {
    type: 'text',
    text: '!',
    label: 'Great Move',
    bgClass: 'bg-[#2ea2cc]',
    textClass: 'text-white',
    borderClass: 'border-[#2283a5]',
    description: 'An exceptional move that was critical to maintaining the advantage.',
  },
  best: {
    type: 'svg',
    label: 'Best Move',
    bgClass: 'bg-[#81b64c]',
    textClass: 'text-white',
    borderClass: 'border-[#659437]',
    description: 'The optimal move chosen by the computer engine.',
  },
  excellent: {
    type: 'svg',
    label: 'Excellent',
    bgClass: 'bg-[#81b64c]',
    textClass: 'text-white',
    borderClass: 'border-[#659437]',
    description: 'An excellent choice almost as good as the engine top pick.',
  },
  good: {
    type: 'svg',
    label: 'Good',
    bgClass: 'bg-[#96bc4b]',
    textClass: 'text-white',
    borderClass: 'border-[#799839]',
    description: 'A solid, healthy move that preserves position quality.',
  },
  book: {
    type: 'svg',
    label: 'Book',
    bgClass: 'bg-[#bfa175]',
    textClass: 'text-white',
    borderClass: 'border-[#9e835b]',
    description: 'Standard opening theory known from grandmaster games.',
  },
  inaccuracy: {
    type: 'text',
    text: '?!',
    label: 'Inaccuracy',
    bgClass: 'bg-[#f7c033]',
    textClass: 'text-slate-900',
    borderClass: 'border-[#cf9f23]',
    description: 'A slight inaccuracy that loses a bit of advantage.',
  },
  mistake: {
    type: 'text',
    text: '?',
    label: 'Mistake',
    bgClass: 'bg-[#f0851e]',
    textClass: 'text-white',
    borderClass: 'border-[#c76b13]',
    description: 'A mistake that swings the position into the opponent\'s favor.',
  },
  miss: {
    type: 'svg',
    label: 'Miss',
    bgClass: 'bg-[#e05353]',
    textClass: 'text-white',
    borderClass: 'border-[#b63c3c]',
    description: 'Missed a key tactic or winning opportunity.',
  },
  blunder: {
    type: 'text',
    text: '??',
    label: 'Blunder',
    bgClass: 'bg-[#fa412d]',
    textClass: 'text-white',
    borderClass: 'border-[#c72d1c]',
    description: 'A disastrous blunder losing significant material or the game.',
  },
  forced: {
    type: 'svg',
    label: 'Forced',
    bgClass: 'bg-[#d4a017]',
    textClass: 'text-white',
    borderClass: 'border-[#aa8012]',
    description: 'The only legal or viable move on the board.',
  },
  checkmate: {
    type: 'text',
    text: '#',
    label: 'Checkmate',
    bgClass: 'bg-slate-900 dark:bg-black',
    textClass: 'text-emerald-400',
    borderClass: 'border-slate-700',
    description: 'The checkmate deliverer that finishes the battle!',
  },
};

// SVG Glyphs exactly matching image.png in white
const BadgeGlyph: React.FC<{ badge: MoveBadgeType; className?: string }> = ({ badge, className = 'w-3 h-3' }) => {
  switch (badge) {
    case 'best': // Star
      return (
        <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
        </svg>
      );
    case 'excellent': // Thumbs up
      return (
        <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
          <path d="M2 20h2c.55 0 1-.45 1-1v-9c0-.55-.45-1-1-1H2v11zm19.83-7.12c.11-.25.17-.52.17-.8 0-1.1-.9-2-2-2h-5.5l.92-4.65c.05-.22.02-.46-.08-.66-.23-.45-.52-.86-.88-1.22L14 3.12 7.88 9.24C7.33 9.79 7 10.54 7 11.33v7.34C7 20.4 8.6 22 10.33 22h7.41c.83 0 1.57-.51 1.87-1.28l2.22-5.84z" />
        </svg>
      );
    case 'good': // Checkmark
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
          <polyline points="20 6 9 17 4 12" />
        </svg>
      );
    case 'book': // Open book
      return (
        <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
          <path d="M21 5c-1.11-.35-2.33-.5-3.5-.5-1.95 0-4.05.4-5.5 1.5-1.45-1.1-3.55-1.5-5.5-1.5S2.45 4.9 1 6v14.65c0 .25.25.5.5.5.1 0 .15-.05.25-.05C3.1 20.45 5.05 20 6.5 20c1.95 0 4.05.4 5.5 1.5 1.35-.85 3.8-1.5 5.5-1.5 1.65 0 3.35.3 4.75 1.05.1.05.15.05.25.05.25 0 .5-.25.5-.5V6c-.6-.45-1.25-.75-2-1zm-1 13c-1.04-.3-2.28-.5-3.5-.5-1.7 0-3.45.45-4.5 1.25V7.5c1.05-.8 2.8-1.25 4.5-1.25 1.22 0 2.46.2 3.5.5v11.25z" />
        </svg>
      );
    case 'miss': // Target / X cross
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
          <line x1="18" y1="6" x2="6" y2="18" />
          <line x1="6" y1="6" x2="18" y2="18" />
        </svg>
      );
    case 'forced': // Crown
      return (
        <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
          <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .55-.45 1-1 1H6c-.55 0-1-.45-1-1v-1h14v1z" />
        </svg>
      );
    default:
      return null;
  }
};

export const AnalysisBadge: React.FC<AnalysisBadgeProps> = ({
  badge,
  size = 'md',
  showLabel = false,
  className = '',
}) => {
  const config = BADGE_CONFIG[badge] || BADGE_CONFIG.good;

  const sizeClasses = {
    xs: 'w-4 h-4 text-[9px]',
    sm: 'w-5 h-5 text-[10px]',
    md: 'w-6 h-6 text-xs shadow-md',
    lg: 'w-8 h-8 text-sm shadow-lg',
  }[size];

  const iconSizes = {
    xs: 'w-2.5 h-2.5',
    sm: 'w-3 h-3',
    md: 'w-3.5 h-3.5',
    lg: 'w-4.5 h-4.5',
  }[size];

  return (
    <div
      className={`inline-flex items-center gap-1.5 select-none ${className}`}
      title={`${config.label}: ${config.description}`}
    >
      <div
        className={`${sizeClasses} ${config.bgClass} ${config.textClass} rounded-full flex items-center justify-center font-bold tracking-tighter leading-none border border-white/20 shadow-sm transition-transform hover:scale-110 shrink-0`}
      >
        {config.type === 'svg' ? (
          <BadgeGlyph badge={badge} className={iconSizes} />
        ) : (
          <span>{config.text}</span>
        )}
      </div>
      {showLabel && (
        <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
          {config.label}
        </span>
      )}
    </div>
  );
};
