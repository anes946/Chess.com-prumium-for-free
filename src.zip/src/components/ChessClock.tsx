import React from 'react';
import { PieceColor } from '../types/chess';
import { Clock } from 'lucide-react';

interface ChessClockProps {
  color: PieceColor;
  playerName: string;
  avatar: string;
  rating?: number;
  timeRemainingSeconds: number;
  isActive: boolean;
  isUnlimited?: boolean;
  capturedMaterialDiff?: number; // e.g. +3 pawns
  capturedPieces?: Array<{ type: string; color: PieceColor }>;
  className?: string;
}

export const ChessClock: React.FC<ChessClockProps> = ({
  color,
  playerName,
  avatar,
  rating,
  timeRemainingSeconds,
  isActive,
  isUnlimited = false,
  capturedMaterialDiff = 0,
  className = '',
}) => {
  const isWhite = color === 'w';

  // Format time mm:ss or ss.s when under 10s
  const formatTime = (seconds: number) => {
    if (isUnlimited) return '∞';
    const totalSec = Math.max(0, seconds);
    const mins = Math.floor(totalSec / 60);
    const secs = Math.floor(totalSec % 60);

    if (totalSec < 10) {
      const tenths = Math.floor((totalSec * 10) % 10);
      return `${secs}.${tenths}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const isLowTime = !isUnlimited && timeRemainingSeconds <= 20;
  const isCriticalTime = !isUnlimited && timeRemainingSeconds <= 10;

  return (
    <div
      className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all duration-200 border ${
        isActive
          ? 'bg-slate-800/90 border-emerald-500/80 shadow-[0_0_15px_rgba(16,185,129,0.15)] ring-1 ring-emerald-500/50'
          : 'bg-slate-900/60 border-slate-800/70 text-slate-400'
      } ${className}`}
    >
      {/* Player info */}
      <div className="flex items-center gap-2.5 min-w-0">
        <div className="relative">
          <div className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center text-lg shadow-sm border border-slate-700 overflow-hidden">
            {avatar.startsWith('http') || avatar.startsWith('data:') ? (
              <img src={avatar} alt={playerName} className="w-full h-full object-cover" />
            ) : (
              <span>{avatar}</span>
            )}
          </div>
          <span
            className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-slate-900 ${
              isWhite ? 'bg-amber-100' : 'bg-slate-800'
            }`}
          />
        </div>

        <div className="flex flex-col min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-sm truncate text-slate-100 max-w-[120px] sm:max-w-[160px]">
              {playerName}
            </span>
            {rating && (
              <span className="text-[11px] font-mono font-medium text-slate-400 bg-slate-800/80 px-1.5 py-0.5 rounded border border-slate-700/50">
                {rating}
              </span>
            )}
          </div>
          {capturedMaterialDiff > 0 && (
            <span className="text-[10px] font-semibold text-emerald-400">
              +{capturedMaterialDiff}
            </span>
          )}
        </div>
      </div>

      {/* Clock display */}
      <div
        className={`flex items-center gap-1.5 px-3 py-1 rounded-lg font-mono font-bold tracking-tight transition-colors ${
          isCriticalTime
            ? 'bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse'
            : isLowTime
            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
            : isActive
            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
            : 'bg-slate-800/60 text-slate-300 border border-slate-700/40'
        }`}
      >
        <Clock className="w-3.5 h-3.5 opacity-70 shrink-0" />
        <span className="text-base sm:text-lg tabular-nums">
          {formatTime(timeRemainingSeconds)}
        </span>
      </div>
    </div>
  );
};
