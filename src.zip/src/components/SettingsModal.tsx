import React from 'react';
import { BoardTheme, GameSettings } from '../types/chess';
import { Settings, Volume2, VolumeX, Eye, Moon, Sun, Check, X } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
}

const THEME_PREVIEWS: Array<{ id: BoardTheme; name: string; light: string; dark: string }> = [
  { id: 'emerald', name: 'Emerald Green', light: '#edeed1', dark: '#779952' },
  { id: 'wood', name: 'Classic Walnut', light: '#f0d9b5', dark: '#b58863' },
  { id: 'midnight', name: 'Midnight Slate', light: '#cbd5e1', dark: '#475569' },
  { id: 'tournament', name: 'Tournament Blue', light: '#dee3e6', dark: '#4a7c9d' },
  { id: 'cyberpunk', name: 'Cyberpunk Neon', light: '#1e293b', dark: '#581c87' },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-slate-100">Game Preferences</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-5 overflow-y-auto max-h-[80vh] scrollbar-thin scrollbar-thumb-slate-800">
          {/* UI Mode (Dark / Light) */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-400">Interface Theme</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onUpdateSettings({ themeMode: 'dark' })}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                  settings.themeMode === 'dark'
                    ? 'bg-slate-800 border-emerald-500 text-emerald-400 shadow-sm'
                    : 'bg-slate-950/50 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>Dark Mode</span>
              </button>
              <button
                onClick={() => onUpdateSettings({ themeMode: 'light' })}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                  settings.themeMode === 'light'
                    ? 'bg-slate-800 border-emerald-500 text-emerald-400 shadow-sm'
                    : 'bg-slate-950/50 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Sun className="w-4 h-4" />
                <span>Light Mode</span>
              </button>
            </div>
          </div>

          {/* Board Themes */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-400">Chessboard Style</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {THEME_PREVIEWS.map((theme) => {
                const isSelected = settings.boardTheme === theme.id;
                return (
                  <button
                    key={theme.id}
                    onClick={() => onUpdateSettings({ boardTheme: theme.id })}
                    className={`flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-800 border-emerald-500 ring-1 ring-emerald-500/50'
                        : 'bg-slate-950/50 border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-md overflow-hidden grid grid-cols-2 grid-rows-2 border border-black/20 shadow-xs shrink-0">
                        <div style={{ backgroundColor: theme.light }} />
                        <div style={{ backgroundColor: theme.dark }} />
                        <div style={{ backgroundColor: theme.dark }} />
                        <div style={{ backgroundColor: theme.light }} />
                      </div>
                      <span className="text-xs font-semibold text-slate-200">{theme.name}</span>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-emerald-400" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sound Controls */}
          <div className="bg-slate-950/50 p-3.5 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {settings.soundEnabled ? (
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <VolumeX className="w-4 h-4 text-slate-500" />
                )}
                <span className="text-xs font-semibold text-slate-200">Sound Effects</span>
              </div>
              <input
                type="checkbox"
                checked={settings.soundEnabled}
                onChange={(e) => onUpdateSettings({ soundEnabled: e.target.checked })}
                className="w-4 h-4 accent-emerald-500 cursor-pointer"
              />
            </div>

            {settings.soundEnabled && (
              <div className="flex items-center gap-3 pt-1">
                <span className="text-[11px] text-slate-400">Volume</span>
                <input
                  type="range"
                  min="0.1"
                  max="1"
                  step="0.05"
                  value={settings.soundVolume}
                  onChange={(e) => onUpdateSettings({ soundVolume: parseFloat(e.target.value) })}
                  className="flex-1 accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                />
                <span className="text-[11px] font-mono text-slate-400 w-8 text-right">
                  {Math.round(settings.soundVolume * 100)}%
                </span>
              </div>
            )}
          </div>

          {/* Toggles */}
          <div className="bg-slate-950/50 p-3.5 rounded-xl border border-slate-800 divide-y divide-slate-800 space-y-2.5">
            <div className="flex items-center justify-between pt-1">
              <span className="text-xs font-medium text-slate-300">Show Legal Move Dots</span>
              <input
                type="checkbox"
                checked={settings.showLegalMoves}
                onChange={(e) => onUpdateSettings({ showLegalMoves: e.target.checked })}
                className="w-4 h-4 accent-emerald-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between pt-2.5">
              <span className="text-xs font-medium text-slate-300">Show Board Coordinates (a-h, 1-8)</span>
              <input
                type="checkbox"
                checked={settings.showCoordinates}
                onChange={(e) => onUpdateSettings({ showCoordinates: e.target.checked })}
                className="w-4 h-4 accent-emerald-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between pt-2.5">
              <span className="text-xs font-medium text-slate-300">Show Evaluation Bar</span>
              <input
                type="checkbox"
                checked={settings.showEvaluationBar}
                onChange={(e) => onUpdateSettings({ showEvaluationBar: e.target.checked })}
                className="w-4 h-4 accent-emerald-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between pt-2.5">
              <span className="text-xs font-medium text-slate-300">Auto-Flip in 2-Player Pass & Play</span>
              <input
                type="checkbox"
                checked={settings.autoFlipOnPvp}
                onChange={(e) => onUpdateSettings({ autoFlipOnPvp: e.target.checked })}
                className="w-4 h-4 accent-emerald-500 cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
