import React, { useState } from 'react';
import { PlayerProfile } from '../types/chess';
import { User, Trophy, Shield, Flame, X, Check, Edit2, Play, Trash2 } from 'lucide-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: PlayerProfile;
  onUpdateProfile: (updated: Partial<PlayerProfile>) => void;
  onLoadArchivedGame?: (pgn: string) => void;
}

const AVATAR_OPTIONS = [
  '♟️', '♞', '♝', '♜', '♛', '♚',
  '🧙‍♂️', '🦁', '🦉', '⚡', '🤖', '🦊',
  '🦅', '👑', '🔥', '⚔️', '🎯', '💎',
];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateProfile,
  onLoadArchivedGame,
}) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(profile.name);
  const [selectedAvatar, setSelectedAvatar] = useState(profile.avatar);

  if (!isOpen) return null;

  const handleSaveName = () => {
    if (nameInput.trim()) {
      onUpdateProfile({ name: nameInput.trim() });
    }
    setIsEditingName(false);
  };

  const handleSelectAvatar = (av: string) => {
    setSelectedAvatar(av);
    onUpdateProfile({ avatar: av });
  };

  const winRate =
    profile.gamesPlayed > 0
      ? Math.round((profile.wins / profile.gamesPlayed) * 100)
      : 0;

  const getRankTitle = (elo: number) => {
    if (elo >= 2400) return 'Grandmaster';
    if (elo >= 2200) return 'Master';
    if (elo >= 1800) return 'Expert';
    if (elo >= 1500) return 'Intermediate';
    if (elo >= 1200) return 'Club Player';
    return 'Apprentice';
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-slate-100">Player Profile & Statistics</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-5 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800">
          {/* Avatar and name card */}
          <div className="flex items-center gap-4 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
            <div className="w-16 h-16 rounded-2xl bg-slate-800 border-2 border-emerald-500/60 flex items-center justify-center text-3xl shadow-md shrink-0">
              {selectedAvatar}
            </div>

            <div className="flex-1 min-w-0">
              {isEditingName ? (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    className="bg-slate-900 border border-emerald-500 rounded-lg px-2.5 py-1 text-sm font-semibold text-slate-100 focus:outline-none w-full"
                    autoFocus
                  />
                  <button
                    onClick={handleSaveName}
                    className="p-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <h4 className="text-lg font-bold text-slate-100 truncate">{profile.name}</h4>
                  <button
                    onClick={() => setIsEditingName(true)}
                    className="text-slate-500 hover:text-slate-300 p-1 cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {getRankTitle(profile.elo)}
                </span>
                <span className="text-xs font-mono font-bold text-slate-400">
                  Rating: <span className="text-emerald-400">{profile.elo}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Avatar picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-2">Choose Avatar</label>
            <div className="grid grid-cols-6 gap-2 bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/80">
              {AVATAR_OPTIONS.map((av) => (
                <button
                  key={av}
                  onClick={() => handleSelectAvatar(av)}
                  className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl transition-all cursor-pointer ${
                    selectedAvatar === av
                      ? 'bg-emerald-600 text-white shadow-md scale-105 ring-2 ring-emerald-400'
                      : 'bg-slate-800/70 hover:bg-slate-700/80'
                  }`}
                >
                  {av}
                </button>
              ))}
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="bg-slate-950/50 border border-slate-800/80 rounded-xl p-3 flex flex-col items-center justify-center text-center">
              <Trophy className="w-4 h-4 text-amber-400 mb-1" />
              <span className="text-[11px] text-slate-400 font-medium">Rating</span>
              <span className="text-lg font-mono font-bold text-slate-100">{profile.elo}</span>
            </div>

            <div className="bg-slate-950/50 border border-slate-800/80 rounded-xl p-3 flex flex-col items-center justify-center text-center">
              <Flame className="w-4 h-4 text-emerald-400 mb-1" />
              <span className="text-[11px] text-slate-400 font-medium">Win Rate</span>
              <span className="text-lg font-mono font-bold text-slate-100">{winRate}%</span>
            </div>

            <div className="bg-slate-950/50 border border-slate-800/80 rounded-xl p-3 flex flex-col items-center justify-center text-center">
              <Shield className="w-4 h-4 text-sky-400 mb-1" />
              <span className="text-[11px] text-slate-400 font-medium">Games</span>
              <span className="text-lg font-mono font-bold text-slate-100">{profile.gamesPlayed}</span>
            </div>

            <div className="bg-slate-950/50 border border-slate-800/80 rounded-xl p-3 flex flex-col items-center justify-center text-center">
              <span className="text-xs font-mono font-bold text-purple-400 mb-1">W-L-D</span>
              <span className="text-[11px] text-slate-400 font-medium">Record</span>
              <span className="text-xs font-mono font-bold text-slate-200">
                {profile.wins}/{profile.losses}/{profile.draws}
              </span>
            </div>
          </div>

          {/* Match history archive */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Saved & Recent Games
              </span>
              <span className="text-[11px] text-slate-500 font-mono">
                {profile.history.length} games recorded
              </span>
            </div>

            <div className="space-y-1.5 max-h-48 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800">
              {profile.history.length === 0 ? (
                <div className="bg-slate-950/30 border border-slate-800/60 rounded-xl p-4 text-center text-xs text-slate-500">
                  No games played yet. Start a match against the AI or in 2-player mode!
                </div>
              ) : (
                profile.history.map((game, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 rounded-xl px-3 py-2 text-xs transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`w-2 h-2 rounded-full ${
                          game.result === 'win'
                            ? 'bg-emerald-400'
                            : game.result === 'loss'
                            ? 'bg-red-400'
                            : 'bg-slate-400'
                        }`}
                      />
                      <div className="flex flex-col">
                        <span className="font-semibold text-slate-200">{game.opponent}</span>
                        <span className="text-[10px] text-slate-500">{game.date}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`font-mono font-bold text-[11px] px-1.5 py-0.5 rounded ${
                          game.result === 'win'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : game.result === 'loss'
                            ? 'bg-red-500/20 text-red-300'
                            : 'bg-slate-700/50 text-slate-300'
                        }`}
                      >
                        {game.result.toUpperCase()}
                        {game.eloChange !== 0 && ` (${game.eloChange > 0 ? '+' : ''}${game.eloChange})`}
                      </span>

                      {game.pgn && onLoadArchivedGame && (
                        <button
                          onClick={() => {
                            onLoadArchivedGame(game.pgn);
                            onClose();
                          }}
                          title="Replay Game"
                          className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-emerald-400 transition-colors cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
