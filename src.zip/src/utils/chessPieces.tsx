import React from 'react';
import { PieceColor, PieceType } from '../types/chess';

export const ChessPieceIcon: React.FC<{
  type: PieceType;
  color: PieceColor;
  className?: string;
}> = ({ type, color, className = 'w-full h-full' }) => {
  const isWhite = color === 'w';

  // Crisp standard Staunton vector paths
  switch (type) {
    case 'k': // King
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <g
            fill={isWhite ? '#ffffff' : '#1e293b'}
            fillRule="evenodd"
            stroke={isWhite ? '#1e293b' : '#f8fafc'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            {/* Cross */}
            <path d="M 22.5,11.63 L 22.5,6" strokeLinejoin="miter" />
            <path d="M 20,8 L 25,8" strokeLinejoin="miter" />
            {/* Crown and arches */}
            <path
              d="M 22.5,25 C 22.5,25 27,17.5 25.5,14.5 C 25.5,14.5 24.5,12 22.5,12 C 20.5,12 19.5,14.5 19.5,14.5 C 18,17.5 22.5,25 22.5,25"
              strokeLinejoin="miter"
            />
            <path d="M 11.5,37 C 17,40.5 27,40.5 32.5,37" />
            <path d="M 11.5,30 C 17,27 27,27 32.5,30" />
            <path d="M 11.5,33.5 C 17,30.5 27,30.5 32.5,33.5" />
            {/* Base */}
            <path d="M 11.5,30 C 11,26 15,22 17.5,18 C 15,16.5 13,18.5 11,20.5 C 10,22 9.5,24 9.5,27 C 9.5,32 11.5,37 11.5,37 C 11.5,37 10.5,39.5 11,40 C 11.5,40.5 14,40.5 22.5,40.5 C 31,40.5 33.5,40.5 34,40 C 34.5,39.5 33.5,37 33.5,37 C 33.5,37 35.5,32 35.5,27 C 35.5,24 35,22 34,20.5 C 32,18.5 30,16.5 27.5,18 C 30,22 34,26 33.5,30" />
          </g>
        </svg>
      );

    case 'q': // Queen
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <g
            fill={isWhite ? '#ffffff' : '#1e293b'}
            fillRule="evenodd"
            stroke={isWhite ? '#1e293b' : '#f8fafc'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="6" cy="12" r="2.75" />
            <circle cx="14" cy="9" r="2.75" />
            <circle cx="22.5" cy="8" r="2.75" />
            <circle cx="31" cy="9" r="2.75" />
            <circle cx="39" cy="12" r="2.75" />
            <path d="M 9,26 C 17.5,24.5 30,24.5 36,26 L 38.5,14.5 L 31,25 L 30.7,11.5 L 25.5,24.5 L 22.5,10.5 L 19.5,24.5 L 14.3,11.5 L 14,25 L 6.5,14.5 Z" />
            <path d="M 9,26 C 9,28 10.5,28 11.5,30 C 12.5,31.5 12.5,31 12,33.5 C 10.5,34.5 10.5,36 11,39 C 11.5,40 13,40.5 22.5,40.5 C 32,40.5 33.5,40 34,39 C 34.5,36 34.5,34.5 33,33.5 C 32.5,31 32.5,31.5 33.5,30 C 34.5,28 36,28 36,26 Z" />
            <path d="M 11.5,30 C 15,29 30,29 33.5,30" />
            <path d="M 12,33.5 C 18,32.5 27,32.5 33,33.5" />
          </g>
        </svg>
      );

    case 'r': // Rook
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <g
            fill={isWhite ? '#ffffff' : '#1e293b'}
            fillRule="evenodd"
            stroke={isWhite ? '#1e293b' : '#f8fafc'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path
              d="M 9,39 L 36,39 L 36,36 L 9,36 Z"
              strokeLinejoin="miter"
            />
            <path
              d="M 12,36 L 12,32 L 33,32 L 33,36 Z"
              strokeLinejoin="miter"
            />
            <path
              d="M 11,14 L 11,9 L 15,9 L 15,11 L 20,11 L 20,9 L 25,9 L 25,11 L 30,11 L 30,9 L 34,9 L 34,14 Z"
              strokeLinejoin="miter"
            />
            <path
              d="M 34,14 L 31,17 L 14,17 L 11,14 Z"
              strokeLinejoin="miter"
            />
            <path
              d="M 31,17 L 31,29.5 L 14,29.5 L 14,17 Z"
              strokeLinejoin="miter"
            />
            <path
              d="M 31,29.5 L 32.5,32 L 12.5,32 L 14,29.5 Z"
              strokeLinejoin="miter"
            />
          </g>
        </svg>
      );

    case 'b': // Bishop
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <g
            fill={isWhite ? '#ffffff' : '#1e293b'}
            fillRule="evenodd"
            stroke={isWhite ? '#1e293b' : '#f8fafc'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M 9,36 C 12.39,35.03 19.11,36.43 22.5,34 C 25.89,36.43 32.61,35.03 36,36 C 36,36 37.65,36.54 39,38 C 38.32,38.97 37.35,38.99 36,38.5 C 32.61,37.53 25.89,38.96 22.5,37.5 C 19.11,38.96 12.39,37.53 9,38.5 C 7.646,38.99 6.677,38.97 6,38 C 7.354,36.54 9,36 9,36 Z" />
            <path d="M 15,32 C 17.5,34.5 27.5,34.5 30,32 C 30.5,30.5 30,30 30,30 C 30,27.5 27.5,26 27.5,26 C 33,24.5 33.5,14.5 22.5,10.5 C 11.5,14.5 12,24.5 17.5,26 C 17.5,26 15,27.5 15,30 C 15,30 14.5,30.5 15,32 Z" />
            <circle cx="22.5" cy="8" r="2.5" />
            <path d="M 17.5,26 L 27.5,26" strokeLinejoin="miter" />
            <path d="M 22.5,15.5 L 22.5,20.5" strokeLinejoin="miter" />
            <path d="M 20,18 L 25,18" strokeLinejoin="miter" />
          </g>
        </svg>
      );

    case 'n': // Knight
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <g
            fill={isWhite ? '#ffffff' : '#1e293b'}
            fillRule="evenodd"
            stroke={isWhite ? '#1e293b' : '#f8fafc'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M 22,10 C 32.5,11 38.5,18 38,39 L 15,39 C 15,36 14,30.5 9,26 C 8.5,25.5 9,24.5 11,24.5 C 13,24.5 14,26 14,26 C 12.5,23.5 10.5,21 8,21 C 7,20.5 8,19 11,19 C 14.5,19 16,21 16,21 C 14.5,18.5 13,16 10,16 C 9,15.5 10,14 13,14 C 18,14 20,16.5 20,16.5 C 20,14.5 19.5,12 18,10.5 C 18,9.5 19.5,9.5 22,10 Z" />
            <path
              d="M 9.5 25.5 A 0.5 0.5 0 1 1 8.5,25.5 A 0.5 0.5 0 1 1 9.5 25.5 Z"
              fill={isWhite ? '#1e293b' : '#ffffff'}
              stroke="none"
            />
            <path
              d="M 15 15.5 A 0.5 1.5 0 1 1 14,15.5 A 0.5 1.5 0 1 1 15 15.5 Z"
              transform="matrix(0.866,0.5,-0.5,0.866,9.693,-5.173)"
              fill={isWhite ? '#1e293b' : '#ffffff'}
              stroke="none"
            />
          </g>
        </svg>
      );

    case 'p': // Pawn
    default:
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <g
            fill={isWhite ? '#ffffff' : '#1e293b'}
            fillRule="evenodd"
            stroke={isWhite ? '#1e293b' : '#f8fafc'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M 22.5,9 C 19.5,9 17.5,11 17.5,14 C 17.5,16 18.5,17.5 20,18.5 C 16.5,20 15,22.5 15,26 C 15,27.5 15.5,29 16.5,30 C 14,31.5 13,34 13,37 L 32,37 C 32,34 31,31.5 28.5,30 C 29.5,29 30,27.5 30,26 C 30,22.5 28.5,20 25,18.5 C 26.5,17.5 27.5,16 27.5,14 C 27.5,11 25.5,9 22.5,9 Z" />
          </g>
        </svg>
      );
  }
};
