import { Chess } from 'chess.js';
import { GameReviewReport, MoveAnalysis, MoveBadgeType, PieceColor } from '../types/chess';
import { evaluateBoard, OPENING_BOOK } from './aiEngine';

// Convert centipawns to winning probability [0, 1] using standard logistic formula
function winProbability(centipawns: number): number {
  return 1 / (1 + Math.pow(10, -centipawns / 400));
}

// Check if a move sequence is in standard opening book
function isBookMove(historyPlies: string[], currentMoveSan: string): boolean {
  if (historyPlies.length > 8) return false;
  const historyKey = historyPlies.join(' ');
  const bookMoves = OPENING_BOOK[historyKey];
  return !!(bookMoves && bookMoves.includes(currentMoveSan));
}

// Evaluate a full game or list of moves and produce report
export function reviewGame(historyMoves: Array<{ san: string; from: string; to: string; color: PieceColor }>): GameReviewReport {
  const chess = new Chess();
  const analyzedMoves: MoveAnalysis[] = [];
  const pliesHistory: string[] = [];

  const badgeCounts = {
    white: {
      brilliant: 0,
      great: 0,
      best: 0,
      excellent: 0,
      good: 0,
      book: 0,
      inaccuracy: 0,
      mistake: 0,
      miss: 0,
      blunder: 0,
      forced: 0,
      checkmate: 0,
    } as Record<MoveBadgeType, number>,
    black: {
      brilliant: 0,
      great: 0,
      best: 0,
      excellent: 0,
      good: 0,
      book: 0,
      inaccuracy: 0,
      mistake: 0,
      miss: 0,
      blunder: 0,
      forced: 0,
      checkmate: 0,
    } as Record<MoveBadgeType, number>,
  };

  let whiteAccSum = 0;
  let blackAccSum = 0;
  let whiteMoveCount = 0;
  let blackMoveCount = 0;

  for (let i = 0; i < historyMoves.length; i++) {
    const item = historyMoves[i];
    const fenBefore = chess.fen();
    const legalMoves = chess.moves({ verbose: true });
    const isOnlyMove = legalMoves.length === 1;

    // Evaluate position before move
    const rawEvalBefore = evaluateBoard(chess);
    // Perspective of current mover: + is good for mover, - is bad
    const moverColor = item.color;
    const moverSign = moverColor === 'w' ? 1 : -1;
    const moverEvalBefore = rawEvalBefore * moverSign;

    // Find best legal move in position before played move
    let bestMoveScore = -Infinity;
    let bestMoveSan = '';
    let bestMoveUci = '';

    for (const testMove of legalMoves) {
      chess.move(testMove);
      const afterTestEval = evaluateBoard(chess) * moverSign; // mover's vantage
      chess.undo();

      if (afterTestEval > bestMoveScore) {
        bestMoveScore = afterTestEval;
        bestMoveSan = testMove.san;
        bestMoveUci = `${testMove.from}${testMove.to}`;
      }
    }

    // Now safely play the actual move
    const pieceBefore = chess.get(item.from as any);
    let moveSuccessful = false;
    try {
      chess.move(item.san);
      moveSuccessful = true;
    } catch {
      try {
        chess.move({ from: item.from, to: item.to, promotion: 'q' });
        moveSuccessful = true;
      } catch (e) {
        console.warn('Analysis move execution fallback for:', item.san);
      }
    }

    if (!moveSuccessful && legalMoves.length > 0) {
      // Fallback: apply first legal move to keep simulation progressing
      chess.move(legalMoves[0]);
    }

    const fenAfter = chess.fen();
    const isCheckmate = chess.isCheckmate();

    const rawEvalAfter = evaluateBoard(chess);
    const moverEvalAfter = rawEvalAfter * moverSign;

    // Centipawn loss = best possible eval after move - actual eval after move
    const cpLoss = Math.max(0, bestMoveScore - moverEvalAfter);

    // Accuracy computation using win probability delta
    const pBefore = winProbability(moverEvalBefore);
    const pAfter = winProbability(moverEvalAfter);
    const accuracy = Math.min(100, Math.max(0, 100 * (1 - (pBefore - pAfter) * 1.5)));

    if (moverColor === 'w') {
      whiteAccSum += accuracy;
      whiteMoveCount++;
    } else {
      blackAccSum += accuracy;
      blackMoveCount++;
    }

    // Determine badge
    let badge: MoveBadgeType = 'good';
    let commentary = 'A solid standard move.';

    const inBook = isBookMove(pliesHistory, item.san);

    if (isCheckmate) {
      badge = 'checkmate';
      commentary = 'Checkmate! The decisive move that wins the game.';
    } else if (isOnlyMove) {
      badge = 'forced';
      commentary = 'Forced move. The only legal option.';
    } else if (inBook) {
      badge = 'book';
      commentary = 'Book move following opening theory.';
    } else if (item.san === bestMoveSan || cpLoss <= 5) {
      // Check for brilliant sacrifice: moved a queen/rook/minor into an attacked square or sacrificed material while winning
      const isSacrifice = (pieceBefore && ['q', 'r', 'b', 'n'].includes(pieceBefore.type)) &&
                          (moverEvalAfter > 150) &&
                          (moverEvalBefore > -100);
      if (isSacrifice && Math.random() > 0.4) {
        badge = 'brilliant';
        commentary = 'Brilliant! A stunning tactical sacrifice maintaining decisive advantage.';
      } else if (moverEvalBefore < -200 && moverEvalAfter > -50) {
        badge = 'great';
        commentary = 'Great move! Found the critical defensive resource.';
      } else {
        badge = 'best';
        commentary = 'Best move. The optimal computer recommendation.';
      }
    } else if (cpLoss <= 25) {
      badge = 'excellent';
      commentary = 'Excellent! Very close to the computer best line.';
    } else if (cpLoss <= 65) {
      badge = 'good';
      commentary = 'Good move that keeps the position sound.';
    } else if (cpLoss <= 140) {
      badge = 'inaccuracy';
      commentary = `Inaccuracy (-${(cpLoss / 100).toFixed(1)} pawns). Better was ${bestMoveSan || 'another line'}.`;
    } else if (cpLoss <= 280) {
      badge = 'mistake';
      commentary = `Mistake (-${(cpLoss / 100).toFixed(1)} pawns). Missed a superior alternative: ${bestMoveSan || 'another line'}.`;
    } else {
      if (moverEvalBefore > 200 && moverEvalAfter < 50) {
        badge = 'miss';
        commentary = `Missed win! Missed ${bestMoveSan} which would have maintained a winning edge.`;
      } else {
        badge = 'blunder';
        commentary = `Blunder (-${(cpLoss / 100).toFixed(1)} pawns). Severe oversight, losing advantage.`;
      }
    }

    // Tally counts
    if (moverColor === 'w') {
      badgeCounts.white[badge] = (badgeCounts.white[badge] || 0) + 1;
    } else {
      badgeCounts.black[badge] = (badgeCounts.black[badge] || 0) + 1;
    }

    analyzedMoves.push({
      san: item.san,
      from: item.from,
      to: item.to,
      color: item.color,
      fenBefore,
      fenAfter,
      evalBefore: moverEvalBefore / 100,
      evalAfter: moverEvalAfter / 100,
      centipawnLoss: cpLoss,
      badge,
      commentary,
      bestMoveSan,
      bestMoveUci,
    });

    pliesHistory.push(item.san);
  }

  const whiteAccuracy = whiteMoveCount > 0 ? Math.round((whiteAccSum / whiteMoveCount) * 10) / 10 : 100;
  const blackAccuracy = blackMoveCount > 0 ? Math.round((blackAccSum / blackMoveCount) * 10) / 10 : 100;

  return {
    whiteAccuracy,
    blackAccuracy,
    moves: analyzedMoves,
    badgeCounts,
  };
}
