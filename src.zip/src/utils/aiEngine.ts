import { Chess, Move } from 'chess.js';
import { AIDifficulty } from '../types/chess';

// Piece material values (centipawns)
const PIECE_VALUES: Record<string, number> = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000,
};

// Piece Square Tables (White perspective, rank 8 down to rank 1)
const PAWN_TABLE = [
  0,  0,  0,  0,  0,  0,  0,  0,
 50, 50, 50, 50, 50, 50, 50, 50,
 10, 10, 20, 30, 30, 20, 10, 10,
  5,  5, 10, 25, 25, 10,  5,  5,
  0,  0,  0, 20, 20,  0,  0,  0,
  5, -5,-10,  0,  0,-10, -5,  5,
  5, 10, 10,-20,-20, 10, 10,  5,
  0,  0,  0,  0,  0,  0,  0,  0,
];

const KNIGHT_TABLE = [
 -50,-40,-30,-30,-30,-30,-40,-50,
 -40,-20,  0,  0,  0,  0,-20,-40,
 -30,  0, 10, 15, 15, 10,  0,-30,
 -30,  5, 15, 20, 20, 15,  5,-30,
 -30,  0, 15, 20, 20, 15,  0,-30,
 -30,  5, 10, 15, 15, 10,  5,-30,
 -40,-20,  0,  5,  5,  0,-20,-40,
 -50,-40,-30,-30,-30,-30,-40,-50,
];

const BISHOP_TABLE = [
 -20,-10,-10,-10,-10,-10,-10,-20,
 -10,  0,  0,  0,  0,  0,  0,-10,
 -10,  0,  5, 10, 10,  5,  0,-10,
 -10,  5,  5, 10, 10,  5,  5,-10,
 -10,  0, 10, 10, 10, 10,  0,-10,
 -10, 10, 10, 10, 10, 10, 10,-10,
 -10,  5,  0,  0,  0,  0,  5,-10,
 -20,-10,-10,-10,-10,-10,-10,-20,
];

const ROOK_TABLE = [
  0,  0,  0,  0,  0,  0,  0,  0,
  5, 10, 10, 10, 10, 10, 10,  5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
  0,  0,  0,  5,  5,  0,  0,  0,
];

const QUEEN_TABLE = [
 -20,-10,-10, -5, -5,-10,-10,-20,
 -10,  0,  0,  0,  0,  0,  0,-10,
 -10,  0,  5,  5,  5,  5,  0,-10,
  -5,  0,  5,  5,  5,  5,  0, -5,
   0,  0,  5,  5,  5,  5,  0, -5,
 -10,  5,  5,  5,  5,  5,  0,-10,
 -10,  0,  5,  0,  0,  0,  0,-10,
 -20,-10,-10, -5, -5,-10,-10,-20,
];

const KING_TABLE_MID = [
 -30,-40,-40,-50,-50,-40,-40,-30,
 -30,-40,-40,-50,-50,-40,-40,-30,
 -30,-40,-40,-50,-50,-40,-40,-30,
 -30,-40,-40,-50,-50,-40,-40,-30,
 -20,-30,-30,-40,-40,-30,-30,-20,
 -10,-20,-20,-20,-20,-20,-20,-10,
  20, 20,  0,  0,  0,  0, 20, 20,
  20, 30, 10,  0,  0, 10, 30, 20,
];

const KING_TABLE_END = [
 -50,-40,-30,-20,-20,-30,-40,-50,
 -30,-20,-10,  0,  0,-10,-20,-30,
 -30,-10, 20, 30, 30, 20,-10,-30,
 -30,-10, 30, 40, 40, 30,-10,-30,
 -30,-10, 30, 40, 40, 30,-10,-30,
 -30,-10, 20, 30, 30, 20,-10,-30,
 -30,-30,  0,  0,  0,  0,-30,-30,
 -50,-30,-30,-30,-30,-30,-30,-50,
];

// Common openings map
export const OPENING_BOOK: Record<string, string[]> = {
  '': ['e4', 'd4', 'Nf3', 'c4'],
  'e4': ['e5', 'c5', 'e6', 'c6'],
  'd4': ['d5', 'Nf6', 'e6'],
  'e4 e5': ['Nf3', 'Bc4', 'Nc3', 'f4'],
  'e4 e5 Nf3': ['Nc6', 'Nf6', 'd6'],
  'e4 e5 Nf3 Nc6': ['Bb5', 'Bc4', 'd4', 'Nc3'],
  'e4 c5': ['Nf3', 'Nc3', 'c3', 'd4'],
  'e4 c5 Nf3': ['d6', 'e6', 'Nc6', 'g6'],
  'd4 d5': ['c4', 'Nf3', 'Bf4', 'e3'],
  'd4 Nf6': ['c4', 'Nf3', 'Bg5', 'g3'],
  'd4 d5 c4': ['e6', 'c6', 'dxc4'],
  'e4 e6': ['d4', 'd3', 'Nf3'],
  'e4 e6 d4': ['d5', 'c5'],
};

// Evaluate static position in centipawns from White's perspective (+ is white advantage, - is black)
export function evaluateBoard(chess: Chess): number {
  if (chess.isCheckmate()) {
    return chess.turn() === 'w' ? -30000 : 30000;
  }
  if (chess.isDraw() || chess.isStalemate() || chess.isThreefoldRepetition() || chess.isInsufficientMaterial()) {
    return 0;
  }

  let whiteScore = 0;
  let blackScore = 0;
  let whiteMaterial = 0;
  let blackMaterial = 0;

  const board = chess.board();

  // Material pass
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (!piece) continue;
      const val = PIECE_VALUES[piece.type] || 0;
      if (piece.color === 'w') {
        if (piece.type !== 'k') whiteMaterial += val;
      } else {
        if (piece.type !== 'k') blackMaterial += val;
      }
    }
  }

  const isEndgame = whiteMaterial + blackMaterial < 2800;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (!piece) continue;

      const baseVal = PIECE_VALUES[piece.type] || 0;
      const isWhite = piece.color === 'w';
      const squareIdx = isWhite ? r * 8 + c : (7 - r) * 8 + c;

      let posBonus = 0;
      switch (piece.type) {
        case 'p':
          posBonus = PAWN_TABLE[squareIdx];
          break;
        case 'n':
          posBonus = KNIGHT_TABLE[squareIdx];
          break;
        case 'b':
          posBonus = BISHOP_TABLE[squareIdx];
          break;
        case 'r':
          posBonus = ROOK_TABLE[squareIdx];
          break;
        case 'q':
          posBonus = QUEEN_TABLE[squareIdx];
          break;
        case 'k':
          posBonus = isEndgame ? KING_TABLE_END[squareIdx] : KING_TABLE_MID[squareIdx];
          break;
      }

      if (isWhite) {
        whiteScore += baseVal + posBonus;
      } else {
        blackScore += baseVal + posBonus;
      }
    }
  }

  return whiteScore - blackScore;
}

// Negamax Quiescence search for captures
function quiesceNegamax(chess: Chess, alpha: number, beta: number, maxDepth: number = 2): number {
  const standPat = evaluateBoard(chess) * (chess.turn() === 'w' ? 1 : -1);
  if (standPat >= beta) return beta;
  if (alpha < standPat) alpha = standPat;
  if (maxDepth <= 0) return standPat;

  const captureMoves = chess.moves({ verbose: true }).filter((m) => m.captured);
  captureMoves.sort((a, b) => {
    const valA = (PIECE_VALUES[a.captured || 'p'] || 0) - (PIECE_VALUES[a.piece] || 0);
    const valB = (PIECE_VALUES[b.captured || 'p'] || 0) - (PIECE_VALUES[b.piece] || 0);
    return valB - valA;
  });

  for (const move of captureMoves) {
    chess.move(move);
    const score = -quiesceNegamax(chess, -beta, -alpha, maxDepth - 1);
    chess.undo();

    if (score >= beta) return beta;
    if (score > alpha) alpha = score;
  }
  return alpha;
}

// Negamax search with alpha-beta pruning
function negamaxSearch(
  chess: Chess,
  depth: number,
  alpha: number,
  beta: number
): { score: number; bestMove?: Move } {
  if (chess.isGameOver()) {
    if (chess.isCheckmate()) return { score: -25000 - depth };
    return { score: 0 };
  }

  if (depth <= 0) {
    return { score: quiesceNegamax(chess, alpha, beta, 2) };
  }

  const moves = chess.moves({ verbose: true });
  // Move ordering: checks, promotions, and captures first
  moves.sort((a, b) => {
    let scoreA = 0;
    let scoreB = 0;
    if (a.captured) scoreA += 1000 + (PIECE_VALUES[a.captured] || 0) - (PIECE_VALUES[a.piece] || 0);
    if (b.captured) scoreB += 1000 + (PIECE_VALUES[b.captured] || 0) - (PIECE_VALUES[b.piece] || 0);
    if (a.san.includes('+')) scoreA += 500;
    if (b.san.includes('+')) scoreB += 500;
    if (a.promotion) scoreA += 900;
    if (b.promotion) scoreB += 900;
    return scoreB - scoreA;
  });

  let bestMove: Move = moves[0];
  let maxScore = -Infinity;

  for (const move of moves) {
    chess.move(move);
    const result = negamaxSearch(chess, depth - 1, -beta, -alpha);
    const currentScore = -result.score;
    chess.undo();

    if (currentScore > maxScore) {
      maxScore = currentScore;
      bestMove = move;
    }
    if (currentScore > alpha) {
      alpha = currentScore;
    }
    if (alpha >= beta) {
      break; // Prune
    }
  }

  return { score: maxScore, bestMove };
}

// Find best move for AI
export function getAIMove(
  fen: string,
  difficulty: AIDifficulty,
  historySan: string[] = []
): { move: Move | null; evalScore: number } {
  const chess = new Chess(fen);
  const legalMoves = chess.moves({ verbose: true });

  if (legalMoves.length === 0) {
    return { move: null, evalScore: 0 };
  }

  // Check opening book for first 6 plies
  if (historySan.length <= 6) {
    const key = historySan.join(' ');
    const bookOptions = OPENING_BOOK[key];
    if (bookOptions && bookOptions.length > 0) {
      const randomBookSan = bookOptions[Math.floor(Math.random() * bookOptions.length)];
      const matchedMove = legalMoves.find((m) => m.san === randomBookSan);
      if (matchedMove) {
        return { move: matchedMove, evalScore: 0 };
      }
    }
  }

  // Difficulty settings
  let depth = 2;
  let blunderChance = 0;

  switch (difficulty) {
    case 'beginner':
      depth = 1;
      blunderChance = 0.35;
      break;
    case 'intermediate':
      depth = 2;
      blunderChance = 0.12;
      break;
    case 'advanced':
      depth = 3;
      blunderChance = 0.03;
      break;
    case 'master':
      depth = 4;
      blunderChance = 0;
      break;
    case 'grandmaster':
      depth = 4;
      blunderChance = 0;
      break;
  }

  // Occasional random move for lower difficulties
  if (Math.random() < blunderChance) {
    const randomMove = legalMoves[Math.floor(Math.random() * legalMoves.length)];
    return { move: randomMove, evalScore: evaluateBoard(chess) };
  }

  const result = negamaxSearch(chess, depth, -Infinity, Infinity);

  return {
    move: result.bestMove || legalMoves[0],
    evalScore: result.score,
  };
}
